/**
 * fecheat Classy Audio Synthesizer & Speech Voice Note Engine
 * Uses Web Audio API for harmonic acoustic tones & Web Speech Synthesis for AI Coach Voice Notes
 */

let audioCtx: AudioContext | null = null;

function getAudioContext(): AudioContext {
  if (!audioCtx) {
    const AudioContextClass = window.AudioContext || (window as any).webkitAudioContext;
    audioCtx = new AudioContextClass();
  }
  if (audioCtx.state === "suspended") {
    audioCtx.resume();
  }
  return audioCtx;
}

/**
 * Play a sophisticated athletic chime for alarms & schedule events
 */
export function playScheduleChime() {
  try {
    const ctx = getAudioContext();
    const now = ctx.currentTime;

    const freqs = [523.25, 659.25, 783.99, 1046.5]; // C5, E5, G5, C6 (Major triad luxury chime)
    freqs.forEach((f, idx) => {
      const osc = ctx.createOscillator();
      const gain = ctx.createGain();

      osc.type = "sine";
      osc.frequency.setValueAtTime(f, now + idx * 0.12);

      gain.gain.setValueAtTime(0, now + idx * 0.12);
      gain.gain.linearRampToValueAtTime(0.18, now + idx * 0.12 + 0.04);
      gain.gain.exponentialRampToValueAtTime(0.001, now + idx * 0.12 + 0.85);

      osc.connect(gain);
      gain.connect(ctx.destination);

      osc.start(now + idx * 0.12);
      osc.stop(now + idx * 0.12 + 0.9);
    });
  } catch (e) {
    console.warn("Audio chime failed to play:", e);
  }
}

/**
 * Play an alert warning chord (for wrong workout form or cheat meal alert)
 */
export function playAlertWarning() {
  try {
    const ctx = getAudioContext();
    const now = ctx.currentTime;

    const freqs = [440, 466.16]; // A4 + Bb4 subtle dissonant pulse
    freqs.forEach((f) => {
      const osc = ctx.createOscillator();
      const gain = ctx.createGain();

      osc.type = "triangle";
      osc.frequency.setValueAtTime(f, now);

      gain.gain.setValueAtTime(0.2, now);
      gain.gain.exponentialRampToValueAtTime(0.001, now + 0.6);

      osc.connect(gain);
      gain.connect(ctx.destination);

      osc.start(now);
      osc.stop(now + 0.65);
    });
  } catch (e) {
    console.warn("Audio warning failed:", e);
  }
}

/**
 * Continuous Alarm loop manager for schedule alarms
 */
let alarmIntervalId: any = null;

export function startAlarmLoop(onBeep?: () => void) {
  stopAlarmLoop();
  playScheduleChime();
  if (onBeep) onBeep();

  alarmIntervalId = setInterval(() => {
    playScheduleChime();
    if (onBeep) onBeep();
  }, 3500);
}

export function stopAlarmLoop() {
  if (alarmIntervalId) {
    clearInterval(alarmIntervalId);
    alarmIntervalId = null;
  }
}

/**
 * Web Speech API Voice Note player for Gemini Form Harm Voice Notes
 */
let activeUtterance: SpeechSynthesisUtterance | null = null;

export function speakVoiceNote(
  text: string,
  onStart?: () => void,
  onEnd?: () => void,
  onError?: () => void
): boolean {
  if (!("speechSynthesis" in window)) {
    console.warn("Speech synthesis not supported in this browser");
    if (onError) onError();
    return false;
  }

  window.speechSynthesis.cancel();

  const utterance = new SpeechSynthesisUtterance(text);
  activeUtterance = utterance;

  // Try to find a crisp, classy voice
  const voices = window.speechSynthesis.getVoices();
  const preferredVoice =
    voices.find((v) => v.lang.startsWith("en") && (v.name.includes("Natural") || v.name.includes("Google") || v.name.includes("Daniel") || v.name.includes("Samantha"))) ||
    voices.find((v) => v.lang.startsWith("en")) ||
    voices[0];

  if (preferredVoice) {
    utterance.voice = preferredVoice;
  }

  utterance.rate = 1.0;
  utterance.pitch = 1.0;

  utterance.onstart = () => {
    if (onStart) onStart();
  };

  utterance.onend = () => {
    activeUtterance = null;
    if (onEnd) onEnd();
  };

  utterance.onerror = () => {
    activeUtterance = null;
    if (onError) onError();
  };

  window.speechSynthesis.speak(utterance);
  return true;
}

export function stopVoiceNote() {
  if ("speechSynthesis" in window) {
    window.speechSynthesis.cancel();
  }
  activeUtterance = null;
}

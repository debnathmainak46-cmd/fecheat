import React, { useState } from "react";
import { 
  UtensilsCrossed, 
  Calendar, 
  AlertTriangle, 
  Sparkles, 
  Edit3, 
  Flame, 
  CheckCircle, 
  ArrowRightLeft, 
  ShieldAlert, 
  Layers, 
  HelpCircle,
  Plus,
  TrendingUp,
  Info
} from "lucide-react";
import { DayDiet, MealItem, CheatAlertAnalysis, FoodAlternative, DietChangeRecord } from "../types";
import { playAlertWarning } from "../utils/audio";

interface DietTrackerProps {
  weekDiet: DayDiet[];
  isIllnessActive: boolean;
  illnessDietSchedule?: { time: string; meal: string }[];
  onUpdateMeal: (dayIndex: number, mealId: string, updatedMeal: Partial<MealItem>) => void;
  onRecordValidDietChange: (dayIndex: number, change: Omit<DietChangeRecord, "id" | "timestamp">) => void;
}

export function DietTracker({
  weekDiet,
  isIllnessActive,
  illnessDietSchedule,
  onUpdateMeal,
  onRecordValidDietChange,
}: DietTrackerProps) {
  const [selectedDayIdx, setSelectedDayIdx] = useState<number>(0);
  const currentDay = weekDiet[selectedDayIdx] || weekDiet[0];

  // Cheat Alert Modal state
  const [isCheatModalOpen, setIsCheatModalOpen] = useState<boolean>(false);
  const [cheatItemInput, setCheatItemInput] = useState<string>("Double Bacon Cheeseburger & Fries");
  const [cheatReasonInput, setCheatReasonInput] = useState<string>("Social dinner with colleagues");
  const [isAnalyzingCheat, setIsAnalyzingCheat] = useState<boolean>(false);
  const [cheatAnalysisResult, setCheatAnalysisResult] = useState<CheatAlertAnalysis | null>(null);

  // Market Shortage Alternative Modal state
  const [isAlternativeModalOpen, setIsAlternativeModalOpen] = useState<boolean>(false);
  const [missingFoodInput, setMissingFoodInput] = useState<string>("Wild Atlantic Salmon");
  const [isSearchingAlternative, setIsSearchingAlternative] = useState<boolean>(false);
  const [alternativeResult, setAlternativeResult] = useState<{
    missingItem: string;
    alternatives: FoodAlternative[];
  } | null>(null);

  // Change Diet by Valid Reason Modal state
  const [isChangeModalOpen, setIsChangeModalOpen] = useState<boolean>(false);
  const [selectedMealForChange, setSelectedMealForChange] = useState<MealItem | null>(null);
  const [newMealNameInput, setNewMealNameInput] = useState<string>("");
  const [validReasonInput, setValidReasonInput] = useState<string>("");

  // Daily totals calculation
  const totalCalories = currentDay.meals.reduce((sum, m) => sum + m.calories, 0);
  const totalProtein = currentDay.meals.reduce((sum, m) => sum + m.protein, 0);
  const totalCarbs = currentDay.meals.reduce((sum, m) => sum + m.carbs, 0);
  const totalFat = currentDay.meals.reduce((sum, m) => sum + m.fat, 0);

  // Trigger Cheat Meal Alert & Dual Impact Analysis
  const handleAnalyzeCheat = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!cheatItemInput.trim()) return;

    playAlertWarning();
    setIsAnalyzingCheat(true);
    try {
      const res = await fetch("/api/gemini/cheat-alert", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          cheatItem: cheatItemInput,
          plannedMeal: currentDay.meals[0]?.name || "Planned meal",
          reason: cheatReasonInput,
        }),
      });
      if (res.ok) {
        const data = await res.json();
        setCheatAnalysisResult(data);
      } else {
        throw new Error("API error");
      }
    } catch (err) {
      console.warn("Using fallback cheat analysis:", err);
      setCheatAnalysisResult({
        item: cheatItemInput,
        alertLevel: "Moderate Cheat",
        estimatedCalories: 890,
        benefits: [
          "Dopaminergic replenishment preventing psychological dietary burnout.",
          "Surplus glycogen stored in liver and skeletal myocytes for maximal power output.",
          "Leptin hormone surge resetting resting metabolic expenditure."
        ],
        harms: [
          "High sodium osmotic shift causing 1.5 - 2.5 kg transient intracellular water retention.",
          "Post-prandial glycemic surge causing reactive drowsiness.",
          "Temporary caloric surplus requiring evening macro adjustment."
        ],
        recoveryProtocol: [
          "Execute a 20-minute brisk walk immediately to mobilize GLUT-4 transporters.",
          "Consume 600ml of filtered mineral water with fresh lemon.",
          "Shift your dinner to lean white fish or egg whites with steamed leafy greens."
        ],
        motivationalQuote: "Discipline is not about perfection, but precision recovery. Channel this glycogen into your next heavy lift."
      });
    } finally {
      setIsAnalyzingCheat(false);
    }
  };

  // Find Market Alternatives
  const handleFindAlternative = async (e?: React.FormEvent) => {
    if (e) e.preventDefault();
    if (!missingFoodInput.trim()) return;

    setIsSearchingAlternative(true);
    try {
      const res = await fetch("/api/gemini/diet-alternative", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          missingFood: missingFoodInput,
          targetMacros: "Equivalent protein & micro-nutrient density",
          dietGoal: "Athletic performance & lean muscle maintenance",
        }),
      });
      if (res.ok) {
        const data = await res.json();
        setAlternativeResult(data);
      } else {
        throw new Error("API error");
      }
    } catch (err) {
      console.warn("Using fallback alternative:", err);
      setAlternativeResult({
        missingItem: missingFoodInput,
        alternatives: [
          {
            name: "Canned Atlantic Mackerel in Spring Water",
            ratio: "120g per 150g fresh salmon",
            macroMatch: "28g Protein, 11g Omega-3 Fats, 0g Carbs (220 kcal)",
            whyItWorks: "Equal or superior bioavailable EPA/DHA fatty acids, zero carbohydrate load, shelf-stable, and readily stocked."
          },
          {
            name: "Extra-Lean Turkey Breast + 1 tbsp Cold-Pressed Flax Oil",
            ratio: "140g turkey + 10ml flax oil",
            macroMatch: "32g Protein, 10g Essential Fats, 0g Carbs (230 kcal)",
            whyItWorks: "Replicates both the lean anabolic amino profile and cellular membrane lipid support."
          },
          {
            name: "Pasture-Raised Whole Eggs with Steamed Spinach",
            ratio: "3 large eggs + 1 cup spinach",
            macroMatch: "21g Protein, 15g Choline-rich Fats, 2g Fiber (240 kcal)",
            whyItWorks: "Universal grocery availability with superior micronutrient density including lutein, zinc, and B12."
          }
        ]
      });
    } finally {
      setIsSearchingAlternative(false);
    }
  };

  // Submit valid diet change
  const handleSubmitDietChange = (e: React.FormEvent) => {
    e.preventDefault();
    if (!selectedMealForChange || !newMealNameInput.trim() || !validReasonInput.trim()) return;

    onRecordValidDietChange(selectedDayIdx, {
      originalMeal: selectedMealForChange.name,
      newMeal: newMealNameInput.trim(),
      validReason: validReasonInput.trim(),
      approvedByAI: true,
    });

    onUpdateMeal(selectedDayIdx, selectedMealForChange.id, {
      name: newMealNameInput.trim(),
      status: "substituted",
      notes: `Changed due to: ${validReasonInput.trim()}`,
    });

    setIsChangeModalOpen(false);
    setSelectedMealForChange(null);
    setNewMealNameInput("");
    setValidReasonInput("");
  };

  return (
    <div className="space-y-6">
      {/* Header & Quick Action Banner */}
      <div className="rounded-2xl border border-neutral-800 bg-neutral-900/90 p-6 shadow-xl">
        <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-4">
          <div>
            <div className="flex items-center gap-2 text-xs font-semibold uppercase tracking-wider text-amber-400">
              <UtensilsCrossed className="h-4 w-4" />
              Comprehensive 7-Day Precision Diet
            </div>
            <h2 className="font-serif text-2xl font-bold text-white mt-1">
              Full Week Diet & Intelligent Cheat Manager
            </h2>
            <p className="text-xs text-neutral-400 mt-1 max-w-2xl">
              Recorded macro and micro-nutrient profiles. Valid reason diet adjustment logging, cheat meal benefit/harm analysis, and grocery shortage alternatives.
            </p>
          </div>

          <div className="flex flex-wrap items-center gap-2">
            <button
              onClick={() => {
                setMissingFoodInput(currentDay.meals[0]?.name || "Wild Salmon");
                setIsAlternativeModalOpen(true);
                handleFindAlternative();
              }}
              className="flex items-center gap-1.5 rounded-xl bg-neutral-950 border border-neutral-700 hover:border-amber-500/40 px-3.5 py-2 text-xs font-medium text-amber-300 transition-colors"
            >
              <ArrowRightLeft className="h-3.5 w-3.5 text-amber-400" />
              <span>Market Shortage Alternative</span>
            </button>

            <button
              onClick={() => {
                setIsCheatModalOpen(true);
                setCheatAnalysisResult(null);
              }}
              className="flex items-center gap-1.5 rounded-xl bg-rose-600/90 hover:bg-rose-500 px-3.5 py-2 text-xs font-bold text-white shadow-md shadow-rose-600/20 transition-all"
            >
              <AlertTriangle className="h-3.5 w-3.5" />
              <span>Log Cheat Meal Alert</span>
            </button>
          </div>
        </div>

        {/* Illness Auto-Diet Alert Banner */}
        {isIllnessActive && (
          <div className="mt-5 rounded-xl border border-rose-700/50 bg-rose-950/40 p-4 space-y-2">
            <div className="flex items-center gap-2 text-rose-300 font-semibold text-xs uppercase tracking-wider">
              <ShieldAlert className="h-4 w-4 text-rose-400" />
              Illness Recovery Protocol Automatically Overriding Schedule
            </div>
            <p className="text-xs text-neutral-300 leading-relaxed">
              Biometric fever/illness detected. Solid dense meats shifted to gut-sparing bone broths, oral electrolytes, and anti-inflammatory compounds as advised by Gemini Health AI.
            </p>
            {illnessDietSchedule && (
              <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-4 gap-2 pt-2">
                {illnessDietSchedule.map((item, idx) => (
                  <div key={idx} className="rounded-lg bg-neutral-950/80 p-2 border border-rose-800/40 text-[11px]">
                    <span className="font-mono text-amber-300 font-bold">{item.time}:</span>{" "}
                    <span className="text-neutral-200">{item.meal}</span>
                  </div>
                ))}
              </div>
            )}
          </div>
        )}

        {/* 7-Day Day Selector */}
        <div className="mt-6 flex overflow-x-auto gap-2 pb-1 scrollbar-none">
          {weekDiet.map((day, idx) => {
            const isSelected = selectedDayIdx === idx;
            return (
              <button
                key={day.dayName}
                onClick={() => setSelectedDayIdx(idx)}
                className={`flex-1 min-w-[110px] rounded-xl p-3 text-left transition-all border ${
                  isSelected
                    ? "bg-amber-500/15 border-amber-500/60 shadow-md shadow-amber-500/5"
                    : "bg-neutral-950/60 border-neutral-800 hover:bg-neutral-900 text-neutral-400"
                }`}
              >
                <div className="text-[10px] font-medium text-neutral-400 uppercase tracking-wider">
                  {day.date}
                </div>
                <div className={`font-serif text-sm font-bold ${isSelected ? "text-amber-300" : "text-white"}`}>
                  {day.dayName}
                </div>
                <div className="mt-1 text-[11px] text-neutral-400">
                  {day.targetCalories} kcal
                </div>
              </button>
            );
          })}
        </div>
      </div>

      {/* Selected Day Daily Nutritional Totals Bar */}
      <div className="grid grid-cols-2 sm:grid-cols-4 gap-4">
        <div className="rounded-xl border border-neutral-800 bg-neutral-900/80 p-4">
          <div className="text-[11px] text-neutral-400 uppercase tracking-wider">Calories</div>
          <div className="mt-1 flex items-baseline gap-1.5">
            <span className="font-serif text-2xl font-bold text-white">{totalCalories}</span>
            <span className="text-xs text-neutral-500">/ {currentDay.targetCalories} kcal</span>
          </div>
          <div className="mt-2 h-1.5 w-full bg-neutral-800 rounded-full overflow-hidden">
            <div
              className="h-full bg-amber-500 rounded-full"
              style={{ width: `${Math.min(100, (totalCalories / currentDay.targetCalories) * 100)}%` }}
            />
          </div>
        </div>

        <div className="rounded-xl border border-neutral-800 bg-neutral-900/80 p-4">
          <div className="text-[11px] text-neutral-400 uppercase tracking-wider">Protein</div>
          <div className="mt-1 flex items-baseline gap-1.5">
            <span className="font-serif text-2xl font-bold text-amber-400">{totalProtein}g</span>
            <span className="text-xs text-neutral-500">/ {currentDay.targetProtein}g</span>
          </div>
          <div className="mt-2 h-1.5 w-full bg-neutral-800 rounded-full overflow-hidden">
            <div
              className="h-full bg-amber-400 rounded-full"
              style={{ width: `${Math.min(100, (totalProtein / currentDay.targetProtein) * 100)}%` }}
            />
          </div>
        </div>

        <div className="rounded-xl border border-neutral-800 bg-neutral-900/80 p-4">
          <div className="text-[11px] text-neutral-400 uppercase tracking-wider">Carbohydrates</div>
          <div className="mt-1 flex items-baseline gap-1.5">
            <span className="font-serif text-2xl font-bold text-sky-400">{totalCarbs}g</span>
            <span className="text-xs text-neutral-500">/ {currentDay.targetCarbs}g</span>
          </div>
          <div className="mt-2 h-1.5 w-full bg-neutral-800 rounded-full overflow-hidden">
            <div
              className="h-full bg-sky-400 rounded-full"
              style={{ width: `${Math.min(100, (totalCarbs / currentDay.targetCarbs) * 100)}%` }}
            />
          </div>
        </div>

        <div className="rounded-xl border border-neutral-800 bg-neutral-900/80 p-4">
          <div className="text-[11px] text-neutral-400 uppercase tracking-wider">Healthy Lipids</div>
          <div className="mt-1 flex items-baseline gap-1.5">
            <span className="font-serif text-2xl font-bold text-emerald-400">{totalFat}g</span>
            <span className="text-xs text-neutral-500">/ {currentDay.targetFat}g</span>
          </div>
          <div className="mt-2 h-1.5 w-full bg-neutral-800 rounded-full overflow-hidden">
            <div
              className="h-full bg-emerald-400 rounded-full"
              style={{ width: `${Math.min(100, (totalFat / currentDay.targetFat) * 100)}%` }}
            />
          </div>
        </div>
      </div>

      {/* Meals List for Selected Day */}
      <div className="space-y-4">
        <div className="flex items-center justify-between">
          <h3 className="font-serif text-lg font-bold text-white">
            {currentDay.dayName} Recorded Meal Architecture
          </h3>
          <span className="text-xs text-neutral-400">
            {currentDay.meals.length} Scheduled Meals
          </span>
        </div>

        {currentDay.meals.map((meal) => (
          <div
            key={meal.id}
            className="rounded-2xl border border-neutral-800 bg-neutral-900/70 p-5 hover:border-neutral-700 transition-all space-y-4"
          >
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
              <div>
                <div className="flex items-center gap-2">
                  <span className="font-mono text-xs text-amber-400 font-semibold">{meal.time}</span>
                  <span className="text-neutral-500 text-xs">•</span>
                  <span className="rounded bg-neutral-800 px-2 py-0.5 text-[10px] font-medium text-neutral-300 uppercase">
                    {meal.type}
                  </span>
                  {meal.status === "substituted" && (
                    <span className="rounded bg-amber-500/10 border border-amber-500/30 px-1.5 py-0.2 text-[10px] text-amber-300 font-medium">
                      Valid Reason Swap
                    </span>
                  )}
                </div>
                <h4 className="font-serif text-base font-bold text-white mt-1">
                  {meal.name}
                </h4>
                {meal.notes && (
                  <p className="text-xs text-neutral-400 mt-0.5">{meal.notes}</p>
                )}
              </div>

              {/* Action buttons per meal */}
              <div className="flex items-center gap-2 self-start sm:self-center">
                <button
                  onClick={() => {
                    setSelectedMealForChange(meal);
                    setNewMealNameInput("");
                    setValidReasonInput("");
                    setIsChangeModalOpen(true);
                  }}
                  className="flex items-center gap-1 px-3 py-1.5 rounded-lg bg-neutral-950 hover:bg-neutral-800 text-xs text-neutral-300 border border-neutral-800 transition-colors"
                  title="Change meal with valid reason"
                >
                  <Edit3 className="h-3.5 w-3.5 text-amber-400" />
                  <span>Change with Reason</span>
                </button>

                <button
                  onClick={() => {
                    setMissingFoodInput(meal.name);
                    setIsAlternativeModalOpen(true);
                    handleFindAlternative();
                  }}
                  className="flex items-center gap-1 px-2.5 py-1.5 rounded-lg bg-neutral-950 hover:bg-neutral-800 text-xs text-neutral-300 border border-neutral-800 transition-colors"
                  title="Find market substitute if not available in store"
                >
                  <ArrowRightLeft className="h-3.5 w-3.5 text-sky-400" />
                  <span className="hidden md:inline">Find Substitute</span>
                </button>
              </div>
            </div>

            {/* Macros pill strip */}
            <div className="flex flex-wrap items-center gap-3 pt-2 border-t border-neutral-800/60 text-xs">
              <div className="text-neutral-300 font-semibold">
                {meal.calories} <span className="text-neutral-500 font-normal">kcal</span>
              </div>
              <span className="text-neutral-700">•</span>
              <div className="text-amber-400">
                P: <span className="font-semibold">{meal.protein}g</span>
              </div>
              <span className="text-neutral-700">•</span>
              <div className="text-sky-400">
                C: <span className="font-semibold">{meal.carbs}g</span>
              </div>
              <span className="text-neutral-700">•</span>
              <div className="text-emerald-400">
                F: <span className="font-semibold">{meal.fat}g</span>
              </div>
              <span className="text-neutral-700">•</span>
              <div className="text-purple-400">
                Fiber: <span className="font-semibold">{meal.fiber}g</span>
              </div>
            </div>

            {/* Micro-Nutrient / Vitamin Boxes (Requirement 5 "box by box differently") */}
            {meal.vitamins && meal.vitamins.length > 0 && (
              <div className="pt-2">
                <div className="text-[11px] uppercase tracking-wider text-neutral-400 mb-2 font-medium">
                  Micro-Nutrient & Vitamin Profile (Box by Box):
                </div>
                <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-2">
                  {meal.vitamins.map((vit, vIdx) => (
                    <div
                      key={vIdx}
                      className="rounded-xl border border-neutral-800 bg-neutral-950/80 p-2.5 space-y-1"
                    >
                      <div className="flex items-center justify-between">
                        <span className="font-semibold text-xs text-white">{vit.name}</span>
                        <span className="font-mono text-xs text-amber-400 font-bold">
                          {vit.amount}
                        </span>
                      </div>
                      <div className="text-[10px] text-neutral-400 leading-tight">
                        {vit.benefit}
                      </div>
                      <div className="flex items-center justify-between text-[10px] text-neutral-500 pt-1">
                        <span>Daily Target</span>
                        <span className="text-emerald-400 font-mono">{vit.dailyPercent}%</span>
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            )}
          </div>
        ))}
      </div>

      {/* Valid Diet Change Audit Log */}
      {currentDay.changeHistory && currentDay.changeHistory.length > 0 && (
        <div className="rounded-2xl border border-neutral-800 bg-neutral-900/60 p-5 space-y-3">
          <h4 className="font-serif text-sm font-bold text-white flex items-center gap-2">
            <Info className="h-4 w-4 text-amber-400" />
            Audited Diet Alteration History ({currentDay.dayName})
          </h4>
          <div className="space-y-2">
            {currentDay.changeHistory.map((rec) => (
              <div
                key={rec.id}
                className="flex flex-col sm:flex-row sm:items-center justify-between text-xs bg-neutral-950 p-3 rounded-xl border border-neutral-800"
              >
                <div>
                  <span className="text-neutral-400 line-through mr-2">{rec.originalMeal}</span>
                  <span className="text-amber-300 font-semibold mr-2">→ {rec.newMeal}</span>
                </div>
                <div className="text-neutral-400 mt-1 sm:mt-0">
                  Reason: <span className="text-neutral-200 italic">"{rec.validReason}"</span>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* 4th REQUIREMENT: Cheat Meal Alert & Dual Impact Modal */}
      {isCheatModalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/80 backdrop-blur-md p-4 overflow-y-auto">
          <div className="w-full max-w-xl rounded-2xl border border-rose-500/40 bg-neutral-950 p-6 shadow-2xl space-y-5">
            <div className="flex items-start justify-between">
              <div>
                <span className="rounded bg-rose-950 border border-rose-700/50 px-2 py-0.5 text-[10px] font-bold text-rose-300 uppercase tracking-wider">
                  Deviation Detection
                </span>
                <h3 className="font-serif text-xl font-bold text-white mt-1">
                  Cheat Meal Alert & Dual Impact Analysis
                </h3>
                <p className="text-xs text-neutral-400">
                  fecheat delivers both physiological benefits & harms along with precise metabolic offset advice.
                </p>
              </div>
              <button
                onClick={() => setIsCheatModalOpen(false)}
                className="text-neutral-500 hover:text-white text-sm"
              >
                ✕
              </button>
            </div>

            <form onSubmit={handleAnalyzeCheat} className="space-y-3">
              <div>
                <label className="block text-xs font-medium text-neutral-300 mb-1">
                  What cheat food or drink was consumed?
                </label>
                <input
                  type="text"
                  required
                  value={cheatItemInput}
                  onChange={(e) => setCheatItemInput(e.target.value)}
                  placeholder="e.g. Double cheeseburger, truffle fries & milkshake"
                  className="w-full rounded-xl bg-neutral-900 border border-neutral-700 px-3 py-2 text-xs text-white placeholder-neutral-500 focus:border-amber-500 focus:outline-none"
                />
              </div>

              <div>
                <label className="block text-xs font-medium text-neutral-300 mb-1">
                  Context / Reason
                </label>
                <input
                  type="text"
                  value={cheatReasonInput}
                  onChange={(e) => setCheatReasonInput(e.target.value)}
                  placeholder="e.g. Birthday celebration with family"
                  className="w-full rounded-xl bg-neutral-900 border border-neutral-700 px-3 py-2 text-xs text-white placeholder-neutral-500 focus:border-amber-500 focus:outline-none"
                />
              </div>

              <div className="flex justify-end">
                <button
                  type="submit"
                  disabled={isAnalyzingCheat}
                  className="flex items-center gap-1.5 rounded-xl bg-rose-600 hover:bg-rose-500 px-4 py-2 text-xs font-bold text-white shadow-md shadow-rose-600/30 transition-all"
                >
                  {isAnalyzingCheat ? (
                    <span>Evaluating Biometrics & Macros...</span>
                  ) : (
                    <>
                      <AlertTriangle className="h-3.5 w-3.5" />
                      <span>Run Dual Impact Evaluation</span>
                    </>
                  )}
                </button>
              </div>
            </form>

            {/* Results Display */}
            {cheatAnalysisResult && (
              <div className="space-y-4 pt-3 border-t border-neutral-800">
                <div className="flex items-center justify-between bg-neutral-900 p-3 rounded-xl border border-neutral-800">
                  <div>
                    <div className="text-xs font-bold text-white">{cheatAnalysisResult.item}</div>
                    <div className="text-[11px] text-neutral-400">
                      Estimated Caloric Surge: <span className="text-amber-400 font-mono font-bold">~{cheatAnalysisResult.estimatedCalories} kcal</span>
                    </div>
                  </div>
                  <span className="rounded bg-rose-950 px-2.5 py-1 text-xs font-bold text-rose-300 border border-rose-800">
                    {cheatAnalysisResult.alertLevel}
                  </span>
                </div>

                {/* Dual Impact: Benefits vs. Harms Side-by-Side */}
                <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
                  {/* Benefits */}
                  <div className="rounded-xl border border-emerald-500/30 bg-emerald-950/20 p-3.5 space-y-2">
                    <div className="text-xs font-bold text-emerald-400 uppercase tracking-wider flex items-center gap-1.5">
                      <CheckCircle className="h-3.5 w-3.5" />
                      Physiological & Mental Benefits:
                    </div>
                    <ul className="space-y-1.5 text-xs text-neutral-300">
                      {cheatAnalysisResult.benefits.map((b, i) => (
                        <li key={i} className="flex items-start gap-1.5">
                          <span className="text-emerald-400 mt-0.5">•</span>
                          <span>{b}</span>
                        </li>
                      ))}
                    </ul>
                  </div>

                  {/* Harms */}
                  <div className="rounded-xl border border-rose-500/30 bg-rose-950/20 p-3.5 space-y-2">
                    <div className="text-xs font-bold text-rose-400 uppercase tracking-wider flex items-center gap-1.5">
                      <AlertTriangle className="h-3.5 w-3.5" />
                      Metabolic & Inflammatory Harms:
                    </div>
                    <ul className="space-y-1.5 text-xs text-neutral-300">
                      {cheatAnalysisResult.harms.map((h, i) => (
                        <li key={i} className="flex items-start gap-1.5">
                          <span className="text-rose-400 mt-0.5">•</span>
                          <span>{h}</span>
                        </li>
                      ))}
                    </ul>
                  </div>
                </div>

                {/* Recovery Protocol */}
                <div className="rounded-xl border border-amber-500/30 bg-neutral-900 p-3.5 space-y-2">
                  <div className="text-xs font-bold text-amber-400 uppercase tracking-wider flex items-center gap-1.5">
                    <TrendingUp className="h-3.5 w-3.5" />
                    Immediate Damage-Control & Recovery Protocol:
                  </div>
                  <div className="space-y-1 text-xs text-neutral-200">
                    {cheatAnalysisResult.recoveryProtocol.map((p, i) => (
                      <div key={i} className="flex items-start gap-2">
                        <span className="font-mono text-amber-400 font-bold">{i + 1}.</span>
                        <span>{p}</span>
                      </div>
                    ))}
                  </div>
                  <p className="text-[11px] italic text-amber-300/80 pt-2 border-t border-neutral-800">
                    "{cheatAnalysisResult.motivationalQuote}"
                  </p>
                </div>
              </div>
            )}
          </div>
        </div>
      )}

      {/* 4th REQUIREMENT: Market Shortage Alternative Modal */}
      {isAlternativeModalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/80 backdrop-blur-md p-4 overflow-y-auto">
          <div className="w-full max-w-lg rounded-2xl border border-neutral-800 bg-neutral-950 p-6 shadow-2xl space-y-5">
            <div className="flex items-start justify-between">
              <div>
                <span className="rounded bg-sky-950 border border-sky-800/50 px-2 py-0.5 text-[10px] font-bold text-sky-300 uppercase tracking-wider">
                  Market Availability Engine
                </span>
                <h3 className="font-serif text-xl font-bold text-white mt-1">
                  Food Not in Market? Find Equivalent
                </h3>
                <p className="text-xs text-neutral-400">
                  fecheat calculates macro-identical grocery alternatives with substitution ratios.
                </p>
              </div>
              <button
                onClick={() => setIsAlternativeModalOpen(false)}
                className="text-neutral-500 hover:text-white text-sm"
              >
                ✕
              </button>
            </div>

            <form onSubmit={handleFindAlternative} className="flex gap-2">
              <input
                type="text"
                required
                value={missingFoodInput}
                onChange={(e) => setMissingFoodInput(e.target.value)}
                placeholder="Missing item, e.g. Wild Salmon, Greek Skyr, Avocado"
                className="flex-1 rounded-xl bg-neutral-900 border border-neutral-700 px-3 py-2 text-xs text-white placeholder-neutral-500 focus:border-amber-500 focus:outline-none"
              />
              <button
                type="submit"
                disabled={isSearchingAlternative}
                className="rounded-xl bg-amber-500 px-4 py-2 text-xs font-semibold text-neutral-950 hover:bg-amber-400"
              >
                {isSearchingAlternative ? "Searching..." : "Find Alternatives"}
              </button>
            </form>

            {alternativeResult && (
              <div className="space-y-3 pt-2">
                <div className="text-xs font-semibold text-neutral-300">
                  Market Equivalents for "{alternativeResult.missingItem}":
                </div>
                <div className="space-y-3">
                  {alternativeResult.alternatives.map((alt, i) => (
                    <div
                      key={i}
                      className="rounded-xl border border-neutral-800 bg-neutral-900/90 p-3.5 space-y-1.5"
                    >
                      <div className="flex items-center justify-between">
                        <h4 className="font-serif text-sm font-bold text-white">{alt.name}</h4>
                        <span className="rounded bg-sky-500/10 border border-sky-500/30 px-2 py-0.5 text-[10px] text-sky-300 font-mono">
                          {alt.ratio}
                        </span>
                      </div>
                      <div className="text-xs text-amber-400 font-mono">
                        {alt.macroMatch}
                      </div>
                      <p className="text-xs text-neutral-400">
                        {alt.whyItWorks}
                      </p>
                    </div>
                  ))}
                </div>
              </div>
            )}
          </div>
        </div>
      )}

      {/* Change Meal with Valid Reason Modal */}
      {isChangeModalOpen && selectedMealForChange && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/80 backdrop-blur-md p-4">
          <div className="w-full max-w-md rounded-2xl border border-neutral-800 bg-neutral-950 p-6 shadow-2xl space-y-4">
            <div className="flex items-start justify-between">
              <div>
                <h3 className="font-serif text-lg font-bold text-white">
                  Alter Meal with Valid Reason
                </h3>
                <p className="text-xs text-neutral-400">
                  Modifying: <span className="text-amber-300 font-semibold">{selectedMealForChange.name}</span>
                </p>
              </div>
              <button
                onClick={() => setIsChangeModalOpen(false)}
                className="text-neutral-500 hover:text-white"
              >
                ✕
              </button>
            </div>

            <form onSubmit={handleSubmitDietChange} className="space-y-3">
              <div>
                <label className="block text-xs font-medium text-neutral-300 mb-1">
                  Replacement Food / Meal
                </label>
                <input
                  type="text"
                  required
                  value={newMealNameInput}
                  onChange={(e) => setNewMealNameInput(e.target.value)}
                  placeholder="e.g. Grass-fed beef steak with roasted potatoes"
                  className="w-full rounded-xl bg-neutral-900 border border-neutral-700 px-3 py-2 text-xs text-white placeholder-neutral-500 focus:border-amber-500 focus:outline-none"
                />
              </div>

              <div>
                <label className="block text-xs font-medium text-neutral-300 mb-1">
                  Valid Reason (Required)
                </label>
                <textarea
                  required
                  rows={3}
                  value={validReasonInput}
                  onChange={(e) => setValidReasonInput(e.target.value)}
                  placeholder="e.g. Traveling across time zones / Out of chicken in local store / Digestive sensitivity"
                  className="w-full rounded-xl bg-neutral-900 border border-neutral-700 px-3 py-2 text-xs text-white placeholder-neutral-500 focus:border-amber-500 focus:outline-none"
                />
              </div>

              <div className="flex justify-end gap-2 pt-2">
                <button
                  type="button"
                  onClick={() => setIsChangeModalOpen(false)}
                  className="px-4 py-2 text-xs text-neutral-400 hover:text-white"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="rounded-xl bg-amber-500 px-5 py-2 text-xs font-semibold text-neutral-950 hover:bg-amber-400"
                >
                  Log & Update Diet
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
}

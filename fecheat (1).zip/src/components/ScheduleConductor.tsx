import React, { useState } from "react";
import { 
  CalendarClock, 
  Plus, 
  Bell, 
  BellOff, 
  CheckCircle2, 
  Clock, 
  Dumbbell, 
  Coffee, 
  Utensils, 
  Moon, 
  Briefcase, 
  Droplets,
  Volume2,
  Trash2
} from "lucide-react";
import { ScheduleItem, ScheduleItemType } from "../types";
import { playScheduleChime } from "../utils/audio";

interface ScheduleConductorProps {
  schedule: ScheduleItem[];
  onToggleComplete: (id: string) => void;
  onToggleAlarm: (id: string) => void;
  onAddScheduleItem: (item: Omit<ScheduleItem, "id">) => void;
  onDeleteScheduleItem?: (id: string) => void;
  onTriggerAlarmModal?: (item: ScheduleItem) => void;
  onTriggerTestAlarm?: (item: ScheduleItem) => void;
  isIllnessActive?: boolean;
}

export function ScheduleConductor({
  schedule,
  onToggleComplete,
  onToggleAlarm,
  onAddScheduleItem,
  onDeleteScheduleItem,
  onTriggerAlarmModal,
  onTriggerTestAlarm,
  isIllnessActive,
}: ScheduleConductorProps) {
  const [filter, setFilter] = useState<string>("all");
  const [isAdding, setIsAdding] = useState<boolean>(false);
  const [newTitle, setNewTitle] = useState<string>("");
  const [newTime, setNewTime] = useState<string>("08:00 AM");
  const [newCategory, setNewCategory] = useState<ScheduleItemType>("workout");
  const [newDuration, setNewDuration] = useState<number>(45);
  const [newDescription, setNewDescription] = useState<string>("");

  const getCategoryIcon = (category: ScheduleItemType) => {
    switch (category) {
      case "morning":
        return <Coffee className="h-4 w-4 text-amber-400" />;
      case "workout":
        return <Dumbbell className="h-4 w-4 text-amber-500" />;
      case "meal":
        return <Utensils className="h-4 w-4 text-emerald-400" />;
      case "hydration":
        return <Droplets className="h-4 w-4 text-sky-400" />;
      case "work":
        return <Briefcase className="h-4 w-4 text-indigo-400" />;
      case "sleep":
      case "recovery":
        return <Moon className="h-4 w-4 text-purple-400" />;
    }
  };

  const completedCount = schedule.filter((i) => i.completed).length;
  const progressPercent = Math.round((completedCount / (schedule.length || 1)) * 100);

  const filteredSchedule = schedule.filter((item) => {
    if (filter === "all") return true;
    if (filter === "workout") return item.category === "workout";
    if (filter === "meal") return item.category === "meal" || item.category === "hydration";
    if (filter === "focus") return item.category === "work" || item.category === "morning" || item.category === "sleep";
    return true;
  });

  const handleCreate = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newTitle.trim()) return;

    // Parse time
    const [timeStr, period] = newTime.split(" ");
    const [h, m] = (timeStr || "08:00").split(":").map(Number);
    let hour = h || 8;
    if (period === "PM" && hour < 12) hour += 12;
    if (period === "AM" && hour === 12) hour = 0;

    onAddScheduleItem({
      title: newTitle.trim(),
      time: newTime,
      hour,
      minute: m || 0,
      category: newCategory,
      durationMinutes: newDuration,
      description: newDescription || "Scheduled routine item",
      completed: false,
      alarmEnabled: true,
      intensityTarget: newCategory === "workout" ? "Moderate" : "Rest",
    });

    setNewTitle("");
    setNewDescription("");
    setIsAdding(false);
  };

  return (
    <div className="space-y-6">
      {/* Overview hero card */}
      <div className="relative overflow-hidden rounded-2xl border border-neutral-800 bg-gradient-to-b from-neutral-900 via-neutral-900/90 to-neutral-950 p-6 shadow-xl">
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-6">
          <div>
            <div className="flex items-center gap-2 text-xs font-semibold uppercase tracking-widest text-amber-400">
              <CalendarClock className="h-4 w-4" />
              24/7 Day-to-Night Schedule Conductor
            </div>
            <h2 className="mt-1 font-serif text-2xl font-bold tracking-tight text-white sm:text-3xl">
              Conduct Your Full Day Without Friction
            </h2>
            <p className="mt-1 max-w-2xl text-sm text-neutral-400">
              Synchronized milestones with active acoustic alarms, wearable biometric syncing, and automated nutritional timing.
            </p>
          </div>

          <div className="flex flex-col sm:flex-row items-start sm:items-center gap-4 bg-neutral-950/60 p-4 rounded-xl border border-neutral-800">
            <div>
              <div className="text-[11px] uppercase tracking-wider text-neutral-400">Daily Adherence</div>
              <div className="flex items-baseline gap-2">
                <span className="font-serif text-3xl font-bold text-amber-400">{progressPercent}%</span>
                <span className="text-xs text-neutral-400">({completedCount}/{schedule.length} Milestones)</span>
              </div>
            </div>
            <button
              onClick={() => setIsAdding(true)}
              className="flex items-center gap-2 rounded-xl bg-amber-500 px-4 py-2.5 text-xs font-semibold text-neutral-950 shadow-md shadow-amber-500/20 hover:bg-amber-400 transition-all"
            >
              <Plus className="h-4 w-4" />
              Add Event
            </button>
          </div>
        </div>

        {/* Progress bar */}
        <div className="mt-6">
          <div className="h-2 w-full overflow-hidden rounded-full bg-neutral-800">
            <div
              className="h-full bg-gradient-to-r from-amber-600 via-amber-500 to-emerald-400 transition-all duration-500"
              style={{ width: `${progressPercent}%` }}
            ></div>
          </div>
        </div>

        {/* Filters */}
        <div className="mt-6 flex flex-wrap items-center gap-2">
          {[
            { id: "all", label: "Full 24-Hour Conduct" },
            { id: "workout", label: "Workouts & Priming" },
            { id: "meal", label: "Nutrition & Hydration" },
            { id: "focus", label: "Focus & Recovery" },
          ].map((btn) => (
            <button
              key={btn.id}
              onClick={() => setFilter(btn.id)}
              className={`rounded-lg px-3 py-1.5 text-xs font-medium transition-all ${
                filter === btn.id
                  ? "bg-amber-500/20 text-amber-300 border border-amber-500/40"
                  : "bg-neutral-950/60 text-neutral-400 hover:text-white border border-neutral-800/80"
              }`}
            >
              {btn.label}
            </button>
          ))}
        </div>
      </div>

      {/* Add event form modal/drawer if open */}
      {isAdding && (
        <form
          onSubmit={handleCreate}
          className="rounded-2xl border border-amber-500/30 bg-neutral-900/95 p-6 shadow-2xl space-y-4"
        >
          <div className="flex items-center justify-between">
            <h3 className="font-serif text-lg font-bold text-white">Add Schedule Milestone</h3>
            <button
              type="button"
              onClick={() => setIsAdding(false)}
              className="text-neutral-400 hover:text-white text-xs"
            >
              Cancel
            </button>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-4 gap-4">
            <div>
              <label className="block text-xs font-medium text-neutral-300 mb-1">Title</label>
              <input
                type="text"
                required
                value={newTitle}
                onChange={(e) => setNewTitle(e.target.value)}
                placeholder="e.g. Hypertrophy Pull Session"
                className="w-full rounded-xl bg-neutral-950 border border-neutral-700 px-3 py-2 text-xs text-white placeholder-neutral-500 focus:border-amber-500 focus:outline-none"
              />
            </div>
            <div>
              <label className="block text-xs font-medium text-neutral-300 mb-1">Time</label>
              <input
                type="text"
                required
                value={newTime}
                onChange={(e) => setNewTime(e.target.value)}
                placeholder="e.g. 05:30 PM"
                className="w-full rounded-xl bg-neutral-950 border border-neutral-700 px-3 py-2 text-xs text-white placeholder-neutral-500 focus:border-amber-500 focus:outline-none"
              />
            </div>
            <div>
              <label className="block text-xs font-medium text-neutral-300 mb-1">Category</label>
              <select
                value={newCategory}
                onChange={(e) => setNewCategory(e.target.value as ScheduleItemType)}
                className="w-full rounded-xl bg-neutral-950 border border-neutral-700 px-3 py-2 text-xs text-white focus:border-amber-500 focus:outline-none"
              >
                <option value="workout">Workout</option>
                <option value="meal">Meal</option>
                <option value="hydration">Hydration</option>
                <option value="work">Focus / Work</option>
                <option value="recovery">Recovery / Sleep</option>
              </select>
            </div>
            <div>
              <label className="block text-xs font-medium text-neutral-300 mb-1">Duration (Min)</label>
              <input
                type="number"
                min={5}
                max={480}
                value={newDuration}
                onChange={(e) => setNewDuration(Number(e.target.value))}
                className="w-full rounded-xl bg-neutral-950 border border-neutral-700 px-3 py-2 text-xs text-white focus:border-amber-500 focus:outline-none"
              />
            </div>
          </div>

          <div>
            <label className="block text-xs font-medium text-neutral-300 mb-1">Description / Notes</label>
            <input
              type="text"
              value={newDescription}
              onChange={(e) => setNewDescription(e.target.value)}
              placeholder="e.g. Focus on latissimus dorsi activation & camera form tracking"
              className="w-full rounded-xl bg-neutral-950 border border-neutral-700 px-3 py-2 text-xs text-white placeholder-neutral-500 focus:border-amber-500 focus:outline-none"
            />
          </div>

          <div className="flex justify-end gap-2 pt-2">
            <button
              type="button"
              onClick={() => setIsAdding(false)}
              className="px-4 py-2 text-xs text-neutral-400 hover:text-white"
            >
              Cancel
            </button>
            <button
              type="submit"
              className="rounded-xl bg-amber-500 px-5 py-2 text-xs font-semibold text-neutral-950 hover:bg-amber-400"
            >
              Save Event
            </button>
          </div>
        </form>
      )}

      {/* Timeline items list */}
      <div className="relative pl-6 sm:pl-8 border-l-2 border-neutral-800 space-y-4">
        {filteredSchedule.map((item) => (
          <div
            key={item.id}
            className={`group relative rounded-xl border p-4 transition-all duration-200 ${
              item.completed
                ? "border-neutral-800/60 bg-neutral-950/40 opacity-75"
                : "border-neutral-800 bg-neutral-900/80 hover:border-amber-500/40 hover:bg-neutral-900 shadow-md"
            }`}
          >
            {/* Timeline node dot */}
            <div
              className={`absolute -left-[31px] sm:-left-[39px] top-5 flex h-6 w-6 items-center justify-center rounded-full border transition-all ${
                item.completed
                  ? "border-emerald-500 bg-emerald-950 text-emerald-400"
                  : "border-amber-500 bg-neutral-950 text-amber-400 group-hover:scale-110"
              }`}
            >
              {item.completed ? (
                <CheckCircle2 className="h-3.5 w-3.5" />
              ) : (
                <span className="h-2 w-2 rounded-full bg-amber-400"></span>
              )}
            </div>

            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
              <div className="flex items-start gap-3">
                <div className="rounded-lg bg-neutral-950 p-2 border border-neutral-800">
                  {getCategoryIcon(item.category)}
                </div>
                <div>
                  <div className="flex items-center gap-2">
                    <span className="font-mono text-xs font-semibold text-amber-400">
                      {item.time}
                    </span>
                    <span className="text-neutral-500 text-xs">•</span>
                    <span className="text-xs text-neutral-400 flex items-center gap-1">
                      <Clock className="h-3 w-3" />
                      {item.durationMinutes}m
                    </span>
                    {item.intensityTarget && item.intensityTarget !== "Rest" && (
                      <span className="rounded bg-amber-500/10 border border-amber-500/20 px-1.5 py-0.2 text-[10px] font-medium text-amber-300">
                        {item.intensityTarget} Target
                      </span>
                    )}
                  </div>
                  <h4 className={`text-base font-semibold ${item.completed ? "text-neutral-400 line-through" : "text-white"}`}>
                    {item.title}
                  </h4>
                  <p className="mt-0.5 text-xs text-neutral-400">
                    {item.description}
                  </p>
                </div>
              </div>

              {/* Action buttons */}
              <div className="flex items-center gap-2 self-end sm:self-center">
                {/* Alarm toggle */}
                <button
                  onClick={() => onToggleAlarm(item.id)}
                  className={`flex items-center gap-1 px-2.5 py-1.5 rounded-lg text-xs font-medium border transition-colors ${
                    item.alarmEnabled
                      ? "bg-amber-500/10 text-amber-300 border-amber-500/30 hover:bg-amber-500/20"
                      : "bg-neutral-950 text-neutral-500 border-neutral-800 hover:text-neutral-300"
                  }`}
                  title={item.alarmEnabled ? "Alarm Armed (will chime)" : "Alarm Muted"}
                >
                  {item.alarmEnabled ? <Bell className="h-3.5 w-3.5" /> : <BellOff className="h-3.5 w-3.5" />}
                  <span className="hidden md:inline">{item.alarmEnabled ? "Armed" : "Muted"}</span>
                </button>

                {/* Alarm preview sound */}
                {item.alarmEnabled && (onTriggerTestAlarm || onTriggerAlarmModal) && (
                  <button
                    onClick={() => {
                      if (onTriggerTestAlarm) onTriggerTestAlarm(item);
                      else if (onTriggerAlarmModal) {
                        playScheduleChime();
                        onTriggerAlarmModal(item);
                      }
                    }}
                    className="p-1.5 rounded-lg bg-neutral-950 border border-neutral-800 text-neutral-400 hover:text-amber-300 hover:border-amber-500/30 transition-colors"
                    title="Test Ring Alarm for this event"
                  >
                    <Volume2 className="h-3.5 w-3.5" />
                  </button>
                )}

                {/* Complete checkbox button */}
                <button
                  onClick={() => onToggleComplete(item.id)}
                  className={`flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-medium transition-all ${
                    item.completed
                      ? "bg-emerald-950/60 text-emerald-300 border border-emerald-800"
                      : "bg-neutral-800 hover:bg-neutral-700 text-neutral-200"
                  }`}
                >
                  <CheckCircle2 className="h-3.5 w-3.5" />
                  <span>{item.completed ? "Done" : "Mark Done"}</span>
                </button>

                {onDeleteScheduleItem && (
                  <button
                    onClick={() => onDeleteScheduleItem(item.id)}
                    className="p-1.5 rounded-lg text-neutral-600 hover:text-rose-400 hover:bg-rose-950/20 transition-colors"
                    title="Remove from schedule"
                  >
                    <Trash2 className="h-3.5 w-3.5" />
                  </button>
                )}
              </div>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}

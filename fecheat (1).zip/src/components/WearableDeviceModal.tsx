import { useState } from "react";
import { 
  Watch, 
  Activity, 
  Smartphone, 
  Download, 
  Bell, 
  Heart, 
  Flame, 
  CheckCircle, 
  Dumbbell, 
  X,
  Volume2,
  AlertTriangle
} from "lucide-react";
import { BiometricsData, ScheduleItem } from "../types";

interface WearableDeviceModalProps {
  isOpen: boolean;
  onClose: () => void;
  biometrics: BiometricsData;
  activeScheduleItem?: ScheduleItem;
  isIllnessActive: boolean;
}

export function WearableDeviceModal({
  isOpen,
  onClose,
  biometrics,
  activeScheduleItem,
  isIllnessActive,
}: WearableDeviceModalProps) {
  const [devicePreview, setDevicePreview] = useState<"round_watch" | "fitness_band">("round_watch");

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/85 backdrop-blur-md p-4 overflow-y-auto">
      <div className="w-full max-w-2xl rounded-2xl border border-neutral-800 bg-neutral-950 p-6 shadow-2xl space-y-6">
        {/* Header */}
        <div className="flex items-center justify-between border-b border-neutral-800 pb-4">
          <div>
            <span className="rounded bg-amber-500/10 border border-amber-500/30 px-2 py-0.5 text-[10px] font-semibold text-amber-300 uppercase tracking-wider">
              Cross-Platform Ecosystem
            </span>
            <h3 className="font-serif text-xl font-bold text-white mt-1">
              Smart Watch & Fitness Band Companion View
            </h3>
            <p className="text-xs text-neutral-400">
              fecheat runs natively on Apple Watch, WearOS, Garmin, and connected fitness bands.
            </p>
          </div>
          <button
            onClick={onClose}
            className="rounded-lg p-1.5 text-neutral-400 hover:text-white hover:bg-neutral-900"
          >
            <X className="h-5 w-5" />
          </button>
        </div>

        {/* Device Format Switcher */}
        <div className="flex justify-center gap-2">
          <button
            onClick={() => setDevicePreview("round_watch")}
            className={`flex items-center gap-2 px-4 py-2 rounded-xl text-xs font-semibold transition-all border ${
              devicePreview === "round_watch"
                ? "bg-amber-500 text-neutral-950 border-amber-400 shadow"
                : "bg-neutral-900 text-neutral-400 border-neutral-800 hover:text-white"
            }`}
          >
            <Watch className="h-4 w-4" />
            Smartwatch View (Round OLED)
          </button>
          <button
            onClick={() => setDevicePreview("fitness_band")}
            className={`flex items-center gap-2 px-4 py-2 rounded-xl text-xs font-semibold transition-all border ${
              devicePreview === "fitness_band"
                ? "bg-amber-500 text-neutral-950 border-amber-400 shadow"
                : "bg-neutral-900 text-neutral-400 border-neutral-800 hover:text-white"
            }`}
          >
            <Activity className="h-4 w-4" />
            Fitness Band View (Slim AMOLED)
          </button>
        </div>

        {/* Visual Device Frame */}
        <div className="flex justify-center py-4">
          {devicePreview === "round_watch" ? (
            /* Round Smartwatch Bezel */
            <div className="relative h-72 w-72 rounded-full border-8 border-neutral-800 bg-neutral-950 shadow-2xl p-6 flex flex-col items-center justify-between text-center overflow-hidden">
              {/* Crown accent on right */}
              <div className="absolute -right-3 top-1/2 -translate-y-1/2 h-8 w-2 rounded-r-md bg-amber-500"></div>

              {/* Time & Connectivity */}
              <div className="pt-2">
                <div className="text-[10px] font-mono text-amber-400 uppercase tracking-widest">
                  fecheat OS
                </div>
                <div className="font-serif text-2xl font-bold text-white">
                  {new Date().toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" })}
                </div>
              </div>

              {/* Center Active Widget */}
              <div className="space-y-1 my-auto">
                {isIllnessActive ? (
                  <div className="rounded-full bg-rose-950/80 border border-rose-600 px-3 py-1">
                    <span className="text-[10px] font-bold text-rose-300">FEVER ALERT: {biometrics.temperature}°F</span>
                  </div>
                ) : (
                  <div className="space-y-0.5">
                    <div className="flex items-center justify-center gap-1 text-[11px] text-amber-300 font-semibold">
                      <Bell className="h-3 w-3 text-amber-400" />
                      <span>{activeScheduleItem?.time || "05:30 PM"}</span>
                    </div>
                    <div className="text-xs font-bold text-white truncate max-w-[170px]">
                      {activeScheduleItem?.title || "Hypertrophy Workout"}
                    </div>
                    <div className="text-[10px] text-neutral-400">Form Sensor Sync Active</div>
                  </div>
                )}

                <div className="flex items-center justify-center gap-3 pt-1">
                  <span className="flex items-center gap-1 text-[11px] text-rose-400 font-bold">
                    <Heart className="h-3 w-3 fill-rose-500" />
                    {biometrics.heartRate}
                  </span>
                  <span className="text-neutral-600 text-xs">|</span>
                  <span className="flex items-center gap-1 text-[11px] text-amber-400 font-bold">
                    <Flame className="h-3 w-3" />
                    {biometrics.caloriesBurned}
                  </span>
                </div>
              </div>

              {/* Bottom Quick Action */}
              <div className="pb-2">
                <span className="rounded-full bg-neutral-900 border border-neutral-700 px-3 py-0.5 text-[9px] text-neutral-300 font-mono">
                  TAP TO SYNC FORM
                </span>
              </div>
            </div>
          ) : (
            /* Fitness Band Slim Display */
            <div className="relative h-80 w-44 rounded-3xl border-8 border-neutral-800 bg-neutral-950 shadow-2xl p-4 flex flex-col justify-between text-center overflow-hidden">
              <div className="flex justify-between items-center text-[9px] text-neutral-500 font-mono px-1">
                <span>fecheat</span>
                <span className="text-emerald-400">98%</span>
              </div>

              <div className="space-y-2 my-auto">
                <div className="font-serif text-3xl font-bold text-white">
                  {new Date().toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" })}
                </div>

                <div className="rounded-xl bg-neutral-900 p-2 border border-neutral-800 space-y-1">
                  <div className="text-[10px] text-neutral-400 uppercase">Live Sensor</div>
                  <div className="flex items-center justify-center gap-1 font-bold text-rose-400 text-sm">
                    <Heart className="h-3.5 w-3.5 fill-rose-500 animate-pulse" />
                    {biometrics.heartRate} bpm
                  </div>
                </div>

                <div className="rounded-xl bg-neutral-900 p-2 border border-neutral-800 text-[10px] text-amber-300">
                  <span className="font-semibold">Form Status:</span> Optimal (0° valgus)
                </div>
              </div>

              <div className="text-[9px] text-neutral-400">
                Steps: <span className="text-white font-mono">{biometrics.steps}</span>
              </div>
            </div>
          )}
        </div>

        {/* Ecosystem Download & Sync Guide */}
        <div className="rounded-xl border border-neutral-800 bg-neutral-900/80 p-4 space-y-2 text-xs">
          <h4 className="font-semibold text-white flex items-center gap-2">
            <Download className="h-4 w-4 text-amber-400" />
            Install fecheat Wearable App on Your Devices
          </h4>
          <p className="text-neutral-400 leading-relaxed">
            Install the fecheat companion watch app to sync form tracking without needing your phone camera in the gym. Automatically streams continuous heart rate, motion acceleration, and core body temperature directly to your schedule conductor.
          </p>
          <div className="flex flex-wrap gap-2 pt-1">
            <span className="rounded-lg bg-neutral-950 border border-neutral-800 px-2.5 py-1 text-[11px] text-neutral-300">
              Apple Watch (watchOS 10+)
            </span>
            <span className="rounded-lg bg-neutral-950 border border-neutral-800 px-2.5 py-1 text-[11px] text-neutral-300">
              WearOS (Galaxy Watch 4/5/6/7)
            </span>
            <span className="rounded-lg bg-neutral-950 border border-neutral-800 px-2.5 py-1 text-[11px] text-neutral-300">
              Garmin Connect IQ
            </span>
            <span className="rounded-lg bg-neutral-950 border border-neutral-800 px-2.5 py-1 text-[11px] text-neutral-300">
              Fitbit / Whoop Bluetooth LE
            </span>
          </div>
        </div>
      </div>
    </div>
  );
}

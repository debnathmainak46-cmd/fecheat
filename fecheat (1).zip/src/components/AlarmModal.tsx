import { useEffect } from "react";
import { Bell, CheckCircle2, Clock, Volume2, X } from "lucide-react";
import { ScheduleItem } from "../types";
import { startAlarmLoop, stopAlarmLoop, playScheduleChime } from "../utils/audio";

interface AlarmModalProps {
  item: ScheduleItem | null;
  isOpen: boolean;
  onDismiss: () => void;
  onSnooze: (item: ScheduleItem) => void;
  onComplete: (item: ScheduleItem) => void;
}

export function AlarmModal({
  item,
  isOpen,
  onDismiss,
  onSnooze,
  onComplete,
}: AlarmModalProps) {
  useEffect(() => {
    if (isOpen && item) {
      startAlarmLoop();
    } else {
      stopAlarmLoop();
    }
    return () => {
      stopAlarmLoop();
    };
  }, [isOpen, item]);

  if (!isOpen || !item) return null;

  const handleDismiss = () => {
    stopAlarmLoop();
    onDismiss();
  };

  const handleSnooze = () => {
    stopAlarmLoop();
    onSnooze(item);
  };

  const handleComplete = () => {
    stopAlarmLoop();
    onComplete(item);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/85 backdrop-blur-lg p-4">
      <div className="relative w-full max-w-md rounded-3xl border border-amber-500/50 bg-neutral-950 p-6 sm:p-8 shadow-2xl text-center space-y-6 animate-in fade-in zoom-in duration-200">
        {/* Ringing Bell Animated Icon */}
        <div className="relative mx-auto flex h-24 w-24 items-center justify-center rounded-full border-2 border-amber-500/40 bg-amber-500/10 shadow-xl shadow-amber-500/20">
          <div className="absolute inset-0 rounded-full border border-amber-400 animate-ping opacity-30"></div>
          <Bell className="h-10 w-10 text-amber-400 animate-bounce" />
        </div>

        <div>
          <div className="flex items-center justify-center gap-1.5 font-mono text-xs font-bold uppercase tracking-widest text-amber-400">
            <Volume2 className="h-3.5 w-3.5 animate-pulse" />
            fecheat Acoustic Alarm Active
          </div>
          <h3 className="font-serif text-2xl sm:text-3xl font-bold text-white mt-2">
            {item.title}
          </h3>
          <div className="flex items-center justify-center gap-2 mt-2 text-sm text-neutral-300 font-mono">
            <Clock className="h-4 w-4 text-amber-400" />
            <span>{item.time}</span>
            <span className="text-neutral-600">•</span>
            <span>{item.durationMinutes} minutes</span>
          </div>
          <p className="text-xs text-neutral-400 mt-2 max-w-xs mx-auto">
            {item.description}
          </p>
        </div>

        {/* Action Controls */}
        <div className="flex flex-col gap-2 pt-2">
          <button
            onClick={handleComplete}
            className="w-full flex items-center justify-center gap-2 rounded-xl bg-amber-500 hover:bg-amber-400 py-3 text-xs font-bold text-neutral-950 shadow-lg shadow-amber-500/25 transition-all"
          >
            <CheckCircle2 className="h-4 w-4" />
            <span>Mark Completed & Dismiss</span>
          </button>

          <div className="grid grid-cols-2 gap-2">
            <button
              onClick={handleSnooze}
              className="rounded-xl border border-neutral-800 bg-neutral-900 hover:bg-neutral-800 py-2.5 text-xs font-medium text-neutral-300 hover:text-white transition-colors"
            >
              Snooze 5 Min
            </button>
            <button
              onClick={handleDismiss}
              className="rounded-xl border border-neutral-800 bg-neutral-900 hover:bg-neutral-800 py-2.5 text-xs font-medium text-neutral-400 hover:text-neutral-200 transition-colors"
            >
              Dismiss Alarm
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}

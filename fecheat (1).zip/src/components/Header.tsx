import { useState, useEffect } from "react";
import { 
  CalendarClock, 
  Dumbbell, 
  UtensilsCrossed, 
  Scan, 
  Activity, 
  Watch, 
  Smartphone, 
  Bell, 
  ShieldAlert,
  Flame,
  HeartPulse
} from "lucide-react";
import { DeviceType, BiometricsData } from "../types";

interface HeaderProps {
  activeTab: any;
  setActiveTab: (tab: any) => void;
  activeDevice: DeviceType;
  setActiveDevice: (device: DeviceType) => void;
  biometrics: BiometricsData;
  isIllnessActive: boolean;
  onTriggerAlarmTest?: () => void;
  onOpenWearablePreview?: () => void;
  onOpenWearableModal?: () => void;
}

export function Header({
  activeTab,
  setActiveTab,
  activeDevice,
  setActiveDevice,
  biometrics,
  isIllnessActive,
  onTriggerAlarmTest,
  onOpenWearablePreview,
  onOpenWearableModal,
}: HeaderProps) {
  const [currentTime, setCurrentTime] = useState<string>("");

  useEffect(() => {
    const updateTime = () => {
      const now = new Date();
      setCurrentTime(
        now.toLocaleTimeString([], { hour: "2-digit", minute: "2-digit", second: "2-digit" })
      );
    };
    updateTime();
    const interval = setInterval(updateTime, 1000);
    return () => clearInterval(interval);
  }, []);

  const navItems = [
    { id: "schedule", label: "Schedule Conductor", icon: CalendarClock },
    { id: "workout", label: "Live Workout Coach", icon: Dumbbell },
    { id: "diet", label: "7-Day Diet & Cheats", icon: UtensilsCrossed },
    { id: "scanner", label: "Meal Scanner", icon: Scan },
    { id: "health", label: "Biometrics & Illness", icon: Activity, alert: isIllnessActive },
  ];

  return (
    <header className="sticky top-0 z-40 border-b border-neutral-800/80 bg-neutral-950/90 backdrop-blur-md">
      {/* Top utility bar */}
      <div className="mx-auto flex max-w-7xl items-center justify-between px-4 py-2 text-xs border-b border-neutral-900/90 text-neutral-400">
        <div className="flex items-center gap-3">
          <span className="flex items-center gap-1.5 font-medium text-amber-400/90 tracking-wide">
            <span className="h-2 w-2 rounded-full bg-emerald-400 animate-pulse"></span>
            LIVE TELEMETRY
          </span>
          <span className="hidden sm:inline text-neutral-600">|</span>
          <span className="hidden sm:flex items-center gap-1.5">
            <HeartPulse className="h-3.5 w-3.5 text-rose-400" />
            <span className="text-neutral-200 font-semibold">{biometrics.heartRate}</span> bpm
          </span>
          <span className="hidden md:inline text-neutral-600">|</span>
          <span className="hidden md:flex items-center gap-1">
            Temp: <span className={biometrics.temperature > 99.5 ? "text-rose-400 font-semibold" : "text-neutral-200"}>{biometrics.temperature}°F</span>
          </span>
          <span className="hidden lg:inline text-neutral-600">|</span>
          <span className="hidden lg:flex items-center gap-1">
            BP: <span className="text-neutral-200">{biometrics.bpSystolic}/{biometrics.bpDiastolic}</span>
          </span>
        </div>

        <div className="flex items-center gap-3">
          {isIllnessActive && (
            <span className="flex items-center gap-1 text-rose-400 bg-rose-950/40 border border-rose-800/50 px-2 py-0.5 rounded-full font-medium">
              <ShieldAlert className="h-3.5 w-3.5 animate-bounce" />
              Illness Protocol Active
            </span>
          )}
          <span className="font-mono text-neutral-300 tracking-wider bg-neutral-900 px-2 py-0.5 rounded border border-neutral-800">
            {currentTime}
          </span>
          <button
            onClick={onTriggerAlarmTest}
            title="Test Schedule Alarm"
            className="flex items-center gap-1 px-2 py-1 rounded bg-neutral-900 hover:bg-neutral-800 text-amber-400 border border-amber-500/20 transition-colors"
          >
            <Bell className="h-3 w-3" />
            <span className="hidden sm:inline">Test Alarm</span>
          </button>
        </div>
      </div>

      {/* Main brand & navigation header */}
      <div className="mx-auto flex max-w-7xl items-center justify-between px-4 py-3 sm:px-6">
        {/* Brand */}
        <div className="flex items-center gap-3">
          <div className="flex h-10 w-10 items-center justify-center rounded-xl bg-gradient-to-br from-amber-500 via-amber-600 to-amber-700 shadow-md shadow-amber-500/10 text-neutral-950 font-black text-xl tracking-tighter">
            f
          </div>
          <div>
            <div className="flex items-center gap-1.5">
              <h1 className="font-serif text-2xl font-bold tracking-tight text-white">
                fecheat
              </h1>
              <span className="rounded bg-amber-500/10 border border-amber-500/30 px-1.5 py-0.2 text-[10px] font-semibold text-amber-300 uppercase tracking-wider">
                Elite AI
              </span>
            </div>
            <p className="text-[11px] text-neutral-400 tracking-wide">
              Full Schedule • Form Sync • Smart Diet Conductor
            </p>
          </div>
        </div>

        {/* Device Sync Mode Switcher */}
        <div className="flex items-center gap-1 sm:gap-2">
          <div className="flex rounded-xl bg-neutral-900/90 p-1 border border-neutral-800">
            <button
              onClick={() => setActiveDevice("phone_camera")}
              className={`flex items-center gap-1.5 rounded-lg px-2.5 py-1.5 text-xs font-medium transition-all ${
                activeDevice === "phone_camera"
                  ? "bg-amber-500 text-neutral-950 shadow-sm"
                  : "text-neutral-400 hover:text-white"
              }`}
              title="Sync via Phone Camera"
            >
              <Smartphone className="h-3.5 w-3.5" />
              <span className="hidden md:inline">Phone Cam</span>
            </button>
            <button
              onClick={() => setActiveDevice("smartwatch")}
              className={`flex items-center gap-1.5 rounded-lg px-2.5 py-1.5 text-xs font-medium transition-all ${
                activeDevice === "smartwatch"
                  ? "bg-amber-500 text-neutral-950 shadow-sm"
                  : "text-neutral-400 hover:text-white"
              }`}
              title="Sync via Smartwatch Camera & Sensors"
            >
              <Watch className="h-3.5 w-3.5" />
              <span className="hidden md:inline">Smart Watch</span>
            </button>
            <button
              onClick={() => setActiveDevice("fitness_band")}
              className={`flex items-center gap-1.5 rounded-lg px-2.5 py-1.5 text-xs font-medium transition-all ${
                activeDevice === "fitness_band"
                  ? "bg-amber-500 text-neutral-950 shadow-sm"
                  : "text-neutral-400 hover:text-white"
              }`}
              title="Sync via Fitness Band Sensors"
            >
              <Activity className="h-3.5 w-3.5" />
              <span className="hidden md:inline">Fitness Band</span>
            </button>
          </div>

          <button
            onClick={() => {
              if (onOpenWearableModal) onOpenWearableModal();
              else if (onOpenWearablePreview) onOpenWearablePreview();
            }}
            className="flex items-center gap-1.5 rounded-xl border border-neutral-800 bg-neutral-900/90 px-3 py-1.5 text-xs font-medium text-amber-300 hover:bg-neutral-800 hover:border-amber-500/40 transition-all"
            title="Preview native Smart Watch or Fitness Band UI"
          >
            <Watch className="h-3.5 w-3.5 text-amber-400" />
            <span className="hidden sm:inline">Watch View</span>
          </button>
        </div>
      </div>

      {/* Tab Navigation */}
      <nav className="mx-auto flex max-w-7xl overflow-x-auto px-4 pb-2 pt-1 sm:px-6 scrollbar-none gap-2">
        {navItems.map((item) => {
          const Icon = item.icon;
          const isActive = activeTab === item.id;
          return (
            <button
              key={item.id}
              onClick={() => setActiveTab(item.id)}
              className={`relative flex items-center gap-2 whitespace-nowrap rounded-lg px-3.5 py-2 text-xs font-medium transition-all ${
                isActive
                  ? "bg-neutral-800 text-amber-300 border border-amber-500/30 shadow-sm shadow-amber-500/5"
                  : "text-neutral-400 hover:bg-neutral-900 hover:text-neutral-200 border border-transparent"
              }`}
            >
              <Icon className={`h-4 w-4 ${isActive ? "text-amber-400" : "text-neutral-400"}`} />
              <span>{item.label}</span>
              {item.alert && (
                <span className="h-2 w-2 rounded-full bg-rose-500 animate-ping"></span>
              )}
            </button>
          );
        })}
      </nav>
    </header>
  );
}

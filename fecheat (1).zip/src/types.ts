export type DeviceType = "phone_camera" | "smartwatch" | "fitness_band";

export type TabType = "schedule" | "workout" | "diet" | "scanner" | "health";

export type ScheduleItemType = "morning" | "workout" | "meal" | "hydration" | "work" | "recovery" | "sleep";

export interface ScheduleItem {
  id: string;
  time: string; // e.g., "07:00 AM"
  hour: number; // 0-23
  minute: number; // 0-59
  title: string;
  category: ScheduleItemType;
  durationMinutes: number;
  description: string;
  completed: boolean;
  alarmEnabled: boolean;
  intensityTarget?: "Rest" | "Low" | "Moderate" | "High" | "Maximum";
}

export interface BiometricsData {
  heartRate: number; // bpm
  restingHeartRate: number;
  temperature: number; // Fahrenheit
  bpSystolic: number;
  bpDiastolic: number;
  spO2: number; // %
  hrv: number; // ms
  steps: number;
  caloriesBurned: number;
  activeIntensity: "Rest" | "Zone 1" | "Zone 2" | "Zone 3" | "Zone 4 Peak";
  syncedAt: string;
}

export interface NutrientBox {
  name: string;
  amount: string;
  dailyPercent: number;
  benefit: string;
}

export interface MealItem {
  id: string;
  name: string;
  time: string;
  type: "Breakfast" | "Mid-Morning" | "Lunch" | "Pre-Workout" | "Dinner" | "Recovery Snack";
  calories: number;
  protein: number; // g
  carbs: number; // g
  fat: number; // g
  fiber: number; // g
  vitamins: NutrientBox[];
  status: "eaten" | "pending" | "cheat" | "substituted";
  notes?: string;
  isIllnessAdjusted?: boolean;
}

export interface DietChangeRecord {
  id: string;
  timestamp: string;
  originalMeal: string;
  newMeal: string;
  validReason: string;
  approvedByAI: boolean;
}

export interface DayDiet {
  dayName: "Monday" | "Tuesday" | "Wednesday" | "Thursday" | "Friday" | "Saturday" | "Sunday";
  date: string;
  targetCalories: number;
  targetProtein: number;
  targetCarbs: number;
  targetFat: number;
  meals: MealItem[];
  changeHistory: DietChangeRecord[];
}

export interface FormFaultTutorial {
  title: string;
  channel: string;
  searchQuery: string;
  focusCue: string;
  youtubeId?: string;
}

export interface FormFaultAnalysis {
  exercise: string;
  mistake: string;
  severity: "Moderate" | "Severe" | "Critical";
  biomechanicalHarms: string[];
  voiceNoteScript: string;
  correctiveCues: string[];
  youtubeTutorials: FormFaultTutorial[];
}

export interface CheatAlertAnalysis {
  item: string;
  alertLevel: "Mild Deviation" | "Moderate Cheat" | "Major Surge";
  estimatedCalories: number;
  benefits: string[];
  harms: string[];
  recoveryProtocol: string[];
  motivationalQuote: string;
}

export interface FoodAlternative {
  name: string;
  ratio: string;
  macroMatch: string;
  whyItWorks: string;
}

export interface IllnessAssessment {
  active: boolean;
  triageStatus: string;
  biometricAnomalySummary: string;
  symptomsReported: string[];
  userConsent: boolean;
  generalMedicines: {
    name: string;
    purpose: string;
    timing: string;
  }[];
  doctorDossier: {
    patientSummary: string;
    symptomTimeline: string;
    vitalsLogged: string;
    flagsForPhysician: string;
  };
  automaticIllnessDietAdjustment: {
    adjustedProtocolName: string;
    rationale: string;
    dailySchedule: { time: string; meal: string }[];
  };
  workoutRecommendation: string;
  detectedAt?: string;
}

import { useState, useEffect } from "react";
import { 
  Calendar, 
  Dumbbell, 
  UtensilsCrossed, 
  Scan, 
  Activity, 
  Watch, 
  Bell, 
  Sparkles,
  ShieldCheck,
  Zap,
  CheckCircle2
} from "lucide-react";
import { 
  TabType, 
  DeviceType, 
  ScheduleItem, 
  DayDiet, 
  BiometricsData, 
  IllnessAssessment, 
  MealItem, 
  NutrientBox,
  DietChangeRecord 
} from "./types";
import { 
  DEFAULT_DAY_SCHEDULE, 
  DEFAULT_WEEK_DIET, 
  DEFAULT_BIOMETRICS,
  DEFAULT_ILLNESS_ASSESSMENT 
} from "./data/defaultData";
import { Header } from "./components/Header";
import { ScheduleConductor } from "./components/ScheduleConductor";
import { WorkoutFormCoach } from "./components/WorkoutFormCoach";
import { DietTracker } from "./components/DietTracker";
import { MealScanner } from "./components/MealScanner";
import { BiometricsHealth } from "./components/BiometricsHealth";
import { WearableDeviceModal } from "./components/WearableDeviceModal";
import { AlarmModal } from "./components/AlarmModal";
import { playScheduleChime } from "./utils/audio";

export default function App() {
  const [activeTab, setActiveTab] = useState<TabType>("schedule");
  const [activeDevice, setActiveDevice] = useState<DeviceType>("phone_camera");
  const [schedule, setSchedule] = useState<ScheduleItem[]>(DEFAULT_DAY_SCHEDULE);
  const [weekDiet, setWeekDiet] = useState<DayDiet[]>(DEFAULT_WEEK_DIET);
  const [biometrics, setBiometrics] = useState<BiometricsData>(DEFAULT_BIOMETRICS);
  const [isIllnessActive, setIsIllnessActive] = useState<boolean>(false);
  const [illnessAssessment, setIllnessAssessment] = useState<IllnessAssessment | null>(null);

  // Modals
  const [activeAlarmItem, setActiveAlarmItem] = useState<ScheduleItem | null>(null);
  const [isWearableModalOpen, setIsWearableModalOpen] = useState<boolean>(false);

  // Schedule Conductor Handlers
  const handleToggleAlarm = (id: string) => {
    setSchedule((prev) =>
      prev.map((item) =>
        item.id === id ? { ...item, alarmEnabled: !item.alarmEnabled } : item
      )
    );
  };

  const handleToggleComplete = (id: string) => {
    setSchedule((prev) =>
      prev.map((item) =>
        item.id === id
          ? { ...item, completed: !item.completed }
          : item
      )
    );
  };

  const handleTriggerTestAlarm = (item: ScheduleItem) => {
    setActiveAlarmItem(item);
  };

  const handleAddScheduleItem = (newItem: Omit<ScheduleItem, "id">) => {
    const item: ScheduleItem = {
      ...newItem,
      id: `sched-${Date.now()}`,
      completed: false,
    };
    setSchedule((prev) => [...prev, item].sort((a, b) => a.time.localeCompare(b.time)));
  };

  // Diet Handlers
  const handleUpdateMeal = (dayIndex: number, mealId: string, updatedMeal: Partial<MealItem>) => {
    setWeekDiet((prev) => {
      const next = [...prev];
      if (next[dayIndex]) {
        next[dayIndex].meals = next[dayIndex].meals.map((m) =>
          m.id === mealId ? { ...m, ...updatedMeal } : m
        );
      }
      return next;
    });
  };

  const handleRecordValidDietChange = (
    dayIndex: number,
    change: Omit<DietChangeRecord, "id" | "timestamp">
  ) => {
    setWeekDiet((prev) => {
      const next = [...prev];
      if (next[dayIndex]) {
        const history = next[dayIndex].changeHistory || [];
        next[dayIndex].changeHistory = [
          ...history,
          {
            ...change,
            id: `change-${Date.now()}`,
            timestamp: new Date().toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" }),
          },
        ];
      }
      return next;
    });
  };

  // Meal Scanner Handler
  const handleAddScannedMealToToday = (mealData: {
    name: string;
    calories: number;
    protein: number;
    carbs: number;
    fat: number;
    fiber: number;
    vitamins: NutrientBox[];
  }) => {
    const newMeal: MealItem = {
      id: `scanned-${Date.now()}`,
      name: mealData.name,
      time: new Date().toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" }),
      type: "Lunch",
      calories: mealData.calories,
      protein: mealData.protein,
      carbs: mealData.carbs,
      fat: mealData.fat,
      fiber: mealData.fiber,
      status: "pending",
      vitamins: mealData.vitamins,
      notes: "Auto-logged via Optical Camera & Sensor Scanner",
    };

    setWeekDiet((prev) => {
      const next = [...prev];
      if (next[0]) {
        next[0].meals = [...next[0].meals, newMeal];
      }
      return next;
    });

    // Update burned / consumed biometrics
    setBiometrics((prev) => ({
      ...prev,
      caloriesConsumed: prev.caloriesConsumed + mealData.calories,
    }));
  };

  // Illness & Biometrics Handlers
  const handleSimulateIllnessSensor = () => {
    setIsIllnessActive(true);
    setBiometrics((prev) => ({
      ...prev,
      temperature: 101.4,
      heartRate: 102,
      activeIntensity: "Rest Restricted",
    }));
    setIllnessAssessment(DEFAULT_ILLNESS_ASSESSMENT);
  };

  const handleResetToHealthyBiometrics = () => {
    setIsIllnessActive(false);
    setBiometrics(DEFAULT_BIOMETRICS);
    setIllnessAssessment(null);
  };

  const handleApplyIllnessAssessment = (assessment: IllnessAssessment) => {
    setIsIllnessActive(true);
    setIllnessAssessment(assessment);
  };

  const handleClearIllness = () => {
    setIsIllnessActive(false);
    setIllnessAssessment(null);
  };

  return (
    <div className="min-h-screen bg-neutral-950 text-neutral-100 selection:bg-amber-500 selection:text-neutral-950 flex flex-col font-sans">
      {/* Top Header */}
      <Header
        activeTab={activeTab}
        setActiveTab={setActiveTab}
        activeDevice={activeDevice}
        setActiveDevice={setActiveDevice}
        biometrics={biometrics}
        isIllnessActive={isIllnessActive}
        onOpenWearableModal={() => setIsWearableModalOpen(true)}
      />

      {/* Main App Navigation Bar */}
      <nav className="border-b border-neutral-800/80 bg-neutral-900/70 sticky top-0 z-40 backdrop-blur-md">
        <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
          <div className="flex overflow-x-auto space-x-1 py-2.5 scrollbar-none">
            {/* 1. Schedule */}
            <button
              onClick={() => setActiveTab("schedule")}
              className={`flex items-center gap-2 whitespace-nowrap rounded-xl px-4 py-2 text-xs font-semibold transition-all ${
                activeTab === "schedule"
                  ? "bg-amber-500 text-neutral-950 shadow-md shadow-amber-500/20"
                  : "text-neutral-400 hover:text-white hover:bg-neutral-800/60"
              }`}
            >
              <Calendar className="h-4 w-4" />
              <span>Full Day Schedule</span>
              <span className="rounded-full bg-neutral-950/40 px-1.5 py-0.2 text-[10px]">
                {schedule.length}
              </span>
            </button>

            {/* 2. Workout & Form Coach */}
            <button
              onClick={() => setActiveTab("workout")}
              className={`flex items-center gap-2 whitespace-nowrap rounded-xl px-4 py-2 text-xs font-semibold transition-all ${
                activeTab === "workout"
                  ? "bg-amber-500 text-neutral-950 shadow-md shadow-amber-500/20"
                  : "text-neutral-400 hover:text-white hover:bg-neutral-800/60"
              }`}
            >
              <Dumbbell className="h-4 w-4" />
              <span>Workout & Form Coach</span>
            </button>

            {/* 3. 7-Day Diet & Cheats */}
            <button
              onClick={() => setActiveTab("diet")}
              className={`flex items-center gap-2 whitespace-nowrap rounded-xl px-4 py-2 text-xs font-semibold transition-all ${
                activeTab === "diet"
                  ? "bg-amber-500 text-neutral-950 shadow-md shadow-amber-500/20"
                  : "text-neutral-400 hover:text-white hover:bg-neutral-800/60"
              }`}
            >
              <UtensilsCrossed className="h-4 w-4" />
              <span>7-Day Diet & Cheats</span>
              {isIllnessActive && (
                <span className="h-2 w-2 rounded-full bg-rose-400 animate-ping"></span>
              )}
            </button>

            {/* 4. Meal Scanner */}
            <button
              onClick={() => setActiveTab("scanner")}
              className={`flex items-center gap-2 whitespace-nowrap rounded-xl px-4 py-2 text-xs font-semibold transition-all ${
                activeTab === "scanner"
                  ? "bg-amber-500 text-neutral-950 shadow-md shadow-amber-500/20"
                  : "text-neutral-400 hover:text-white hover:bg-neutral-800/60"
              }`}
            >
              <Scan className="h-4 w-4" />
              <span>Camera & Sensor Meal Scanner</span>
            </button>

            {/* 5. Biometrics & Doctor Dossier */}
            <button
              onClick={() => setActiveTab("health")}
              className={`flex items-center gap-2 whitespace-nowrap rounded-xl px-4 py-2 text-xs font-semibold transition-all ${
                activeTab === "health"
                  ? "bg-amber-500 text-neutral-950 shadow-md shadow-amber-500/20"
                  : "text-neutral-400 hover:text-white hover:bg-neutral-800/60"
              }`}
            >
              <Activity className="h-4 w-4" />
              <span>Optical Health & Doctor Dossier</span>
              {isIllnessActive && (
                <span className="rounded bg-rose-600 px-1.5 py-0.2 text-[10px] font-bold text-white uppercase">
                  Alert
                </span>
              )}
            </button>
          </div>
        </div>
      </nav>

      {/* Main Content Area */}
      <main className="mx-auto max-w-7xl flex-1 px-4 sm:px-6 lg:px-8 py-8 w-full">
        {activeTab === "schedule" && (
          <ScheduleConductor
            schedule={schedule}
            onToggleAlarm={handleToggleAlarm}
            onToggleComplete={handleToggleComplete}
            onTriggerTestAlarm={handleTriggerTestAlarm}
            onAddScheduleItem={handleAddScheduleItem}
            isIllnessActive={isIllnessActive}
          />
        )}

        {activeTab === "workout" && (
          <WorkoutFormCoach
            activeDevice={activeDevice}
            setActiveDevice={setActiveDevice}
            biometrics={biometrics}
          />
        )}

        {activeTab === "diet" && (
          <DietTracker
            weekDiet={weekDiet}
            isIllnessActive={isIllnessActive}
            illnessDietSchedule={illnessAssessment?.automaticIllnessDietAdjustment.dailySchedule}
            onUpdateMeal={handleUpdateMeal}
            onRecordValidDietChange={handleRecordValidDietChange}
          />
        )}

        {activeTab === "scanner" && (
          <MealScanner onAddScannedMealToToday={handleAddScannedMealToToday} />
        )}

        {activeTab === "health" && (
          <BiometricsHealth
            biometrics={biometrics}
            isIllnessActive={isIllnessActive}
            illnessAssessment={illnessAssessment}
            onSimulateIllnessSensor={handleSimulateIllnessSensor}
            onResetToHealthyBiometrics={handleResetToHealthyBiometrics}
            onApplyIllnessAssessment={handleApplyIllnessAssessment}
            onClearIllness={handleClearIllness}
          />
        )}
      </main>

      {/* Footer */}
      <footer className="border-t border-neutral-800/80 bg-neutral-950 py-6 text-center text-xs text-neutral-500">
        <div className="mx-auto max-w-7xl px-4 flex flex-col sm:flex-row items-center justify-between gap-3">
          <div className="flex items-center gap-2">
            <span className="font-serif font-bold text-white tracking-wider">fecheat</span>
            <span className="text-neutral-700">|</span>
            <span>Intelligent Biomechanical & Day-to-Night Schedule Conductor</span>
          </div>
          <div className="flex items-center gap-4 text-[11px]">
            <span className="flex items-center gap-1 text-emerald-400">
              <ShieldCheck className="h-3.5 w-3.5" />
              Gemini AI Engine Active
            </span>
            <span>•</span>
            <button
              onClick={() => setIsWearableModalOpen(true)}
              className="hover:text-amber-400 transition-colors"
            >
              Companion Wearable Hub
            </button>
          </div>
        </div>
      </footer>

      {/* Acoustic Alarm Modal (Instruction 6) */}
      <AlarmModal
        item={activeAlarmItem}
        isOpen={!!activeAlarmItem}
        onDismiss={() => setActiveAlarmItem(null)}
        onSnooze={(item) => {
          setActiveAlarmItem(null);
          // Snooze 5 min notification
        }}
        onComplete={(item) => {
          handleToggleComplete(item.id);
          setActiveAlarmItem(null);
        }}
      />

      {/* Smartwatch & Band Companion View Modal (Instruction 10) */}
      <WearableDeviceModal
        isOpen={isWearableModalOpen}
        onClose={() => setIsWearableModalOpen(false)}
        biometrics={biometrics}
        activeScheduleItem={schedule.find((s) => !s.completed)}
        isIllnessActive={isIllnessActive}
      />
    </div>
  );
}

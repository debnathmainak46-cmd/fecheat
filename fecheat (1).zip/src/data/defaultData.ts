import { ScheduleItem, DayDiet, BiometricsData, FormFaultAnalysis } from "../types";

export const DEFAULT_SCHEDULE: ScheduleItem[] = [
  {
    id: "sch-1",
    time: "06:30 AM",
    hour: 6,
    minute: 30,
    title: "Morning Sunlight & Hydration",
    category: "morning",
    durationMinutes: 20,
    description: "Drink 750ml spring water with pink salt & lemon. 15 min natural optical circadian exposure.",
    completed: true,
    alarmEnabled: true,
    intensityTarget: "Rest",
  },
  {
    id: "sch-2",
    time: "07:15 AM",
    hour: 7,
    minute: 15,
    title: "Anabolic Breakfast & Electrolytes",
    category: "meal",
    durationMinutes: 30,
    description: "Pasture-raised eggs, sourdough toast, avocado, black coffee.",
    completed: true,
    alarmEnabled: true,
    intensityTarget: "Rest",
  },
  {
    id: "sch-3",
    time: "08:30 AM",
    hour: 8,
    minute: 30,
    title: "Deep Cognitive Focus Block 1",
    category: "work",
    durationMinutes: 120,
    description: "High-priority analytical & executive output without distraction.",
    completed: true,
    alarmEnabled: false,
    intensityTarget: "Rest",
  },
  {
    id: "sch-4",
    time: "11:00 AM",
    hour: 11,
    minute: 0,
    title: "Mid-Morning Bio-Hydration & Mobility",
    category: "hydration",
    durationMinutes: 15,
    description: "500ml water + thoracic spine foam rolling & hip flexor openers.",
    completed: false,
    alarmEnabled: true,
    intensityTarget: "Low",
  },
  {
    id: "sch-5",
    time: "01:00 PM",
    hour: 13,
    minute: 0,
    title: "Clean Macronutrient Lunch",
    category: "meal",
    durationMinutes: 40,
    description: "Grilled chicken breast, quinoa bowl, olive oil greens.",
    completed: false,
    alarmEnabled: true,
    intensityTarget: "Rest",
  },
  {
    id: "sch-6",
    time: "04:45 PM",
    hour: 16,
    minute: 45,
    title: "Pre-Workout Fuel & Joint Priming",
    category: "meal",
    durationMinutes: 25,
    description: "Rice cake with almond butter + raw honey. Dynamic warmup drills.",
    completed: false,
    alarmEnabled: true,
    intensityTarget: "Low",
  },
  {
    id: "sch-7",
    time: "05:30 PM",
    hour: 17,
    minute: 30,
    title: "Heavy Resistance Training & Form Tracking",
    category: "workout",
    durationMinutes: 75,
    description: "Squats, Romanian deadlifts & accessory hyper-extensions. AI form camera sync active.",
    completed: false,
    alarmEnabled: true,
    intensityTarget: "High",
  },
  {
    id: "sch-8",
    time: "07:30 PM",
    hour: 19,
    minute: 30,
    title: "Recovery Dinner & Micro-Nutrients",
    category: "meal",
    durationMinutes: 45,
    description: "Wild salmon fillet, roasted sweet potatoes, steamed broccoli.",
    completed: false,
    alarmEnabled: true,
    intensityTarget: "Rest",
  },
  {
    id: "sch-9",
    time: "09:30 PM",
    hour: 21,
    minute: 30,
    title: "Digital Sunset & Parasympathetic Wind-Down",
    category: "recovery",
    durationMinutes: 45,
    description: "Blue light blocking glasses, magnesium glycinate (400mg), nasal breathing.",
    completed: false,
    alarmEnabled: true,
    intensityTarget: "Rest",
  },
  {
    id: "sch-10",
    time: "10:30 PM",
    hour: 22,
    minute: 30,
    title: "Deep Stage REM Sleep Anchor",
    category: "sleep",
    durationMinutes: 480,
    description: "66°F room temp, 100% blacked-out room. Smartwatch sleep staging active.",
    completed: false,
    alarmEnabled: true,
    intensityTarget: "Rest",
  },
];

export const DEFAULT_WEEK_DIET: DayDiet[] = [
  {
    dayName: "Monday",
    date: "Sep 14",
    targetCalories: 2600,
    targetProtein: 190,
    targetCarbs: 270,
    targetFat: 75,
    changeHistory: [],
    meals: [
      {
        id: "m-mon-1",
        name: "Pasture Eggs & Organic Sourdough",
        time: "07:30 AM",
        type: "Breakfast",
        calories: 560,
        protein: 38,
        carbs: 45,
        fat: 22,
        fiber: 5,
        status: "eaten",
        vitamins: [
          { name: "Vitamin B12", amount: "2.8 mcg", dailyPercent: 116, benefit: "Cognitive acuity & heme synthesis" },
          { name: "Vitamin D3", amount: "12 mcg", dailyPercent: 60, benefit: "Endocrine & skeletal integrity" },
          { name: "Choline", amount: "420 mg", dailyPercent: 76, benefit: "Cellular membrane fluidity" }
        ],
        notes: "Cooked in 1 tsp grass-fed butter with microgreens."
      },
      {
        id: "m-mon-2",
        name: "Wild Atlantic Salmon & Quinoa Pilaf",
        time: "01:00 PM",
        type: "Lunch",
        calories: 680,
        protein: 52,
        carbs: 58,
        fat: 24,
        fiber: 8,
        status: "pending",
        vitamins: [
          { name: "Omega-3 (EPA/DHA)", amount: "2400 mg", dailyPercent: 150, benefit: "Systemic vascular anti-inflammation" },
          { name: "Vitamin C", amount: "48 mg", dailyPercent: 53, benefit: "Collagen biosynthesis" },
          { name: "Potassium", amount: "890 mg", dailyPercent: 26, benefit: "Muscle glycogen storage osmotic flux" }
        ],
        notes: "Served with lemon-drizzled steamed asparagus."
      },
      {
        id: "m-mon-3",
        name: "Pre-Workout Honey & Whey Isolate",
        time: "04:45 PM",
        type: "Pre-Workout",
        calories: 310,
        protein: 30,
        carbs: 42,
        fat: 2,
        fiber: 1,
        status: "pending",
        vitamins: [
          { name: "Sodium & Electrolytes", amount: "380 mg", dailyPercent: 18, benefit: "Maintains plasma volume under exertion" },
          { name: "Calcium", amount: "180 mg", dailyPercent: 18, benefit: "Actin-myosin bridge binding" }
        ],
        notes: "Consuming 45 mins prior to heavy squat session."
      },
      {
        id: "m-mon-4",
        name: "Grass-Fed Flank Steak & Sweet Potato Puree",
        time: "07:45 PM",
        type: "Dinner",
        calories: 780,
        protein: 56,
        carbs: 72,
        fat: 22,
        fiber: 9,
        status: "pending",
        vitamins: [
          { name: "Bioavailable Iron", amount: "4.8 mg", dailyPercent: 37, benefit: "Restores myoglobin oxygen reservoirs" },
          { name: "Zinc Picolinate", amount: "6.2 mg", dailyPercent: 56, benefit: "Protein translation & nocturnal repair" },
          { name: "Vitamin A", amount: "1200 mcg", dailyPercent: 133, benefit: "Epithelial repair & immune support" }
        ],
        notes: "Sweet potato seasoned with cinnamon & sea salt."
      }
    ]
  },
  {
    dayName: "Tuesday",
    date: "Sep 15",
    targetCalories: 2550,
    targetProtein: 195,
    targetCarbs: 250,
    targetFat: 78,
    changeHistory: [],
    meals: [
      {
        id: "m-tue-1",
        name: "High-Protein Greek Skyr with Berries & Walnuts",
        time: "07:30 AM",
        type: "Breakfast",
        calories: 520,
        protein: 45,
        carbs: 42,
        fat: 16,
        fiber: 7,
        status: "pending",
        vitamins: [
          { name: "Calcium", amount: "450 mg", dailyPercent: 45, benefit: "Bone density & neuromuscular conduction" },
          { name: "Vitamin C", amount: "65 mg", dailyPercent: 72, benefit: "Polyphenol antioxidant protection" },
          { name: "Zinc", amount: "2.8 mg", dailyPercent: 25, benefit: "Enzymatic immune maintenance" }
        ]
      },
      {
        id: "m-tue-2",
        name: "Grilled Chicken Breast with Brown Rice & Avocado",
        time: "01:00 PM",
        type: "Lunch",
        calories: 690,
        protein: 58,
        carbs: 64,
        fat: 20,
        fiber: 8,
        status: "pending",
        vitamins: [
          { name: "Vitamin B6", amount: "1.4 mg", dailyPercent: 82, benefit: "Neurotransmitter synthesis & amino metabolism" },
          { name: "Magnesium", amount: "115 mg", dailyPercent: 27, benefit: "Reduces arterial vascular stiffness" }
        ]
      },
      {
        id: "m-tue-3",
        name: "Slow-Braised Turkey & Roasted Root Vegetables",
        time: "07:45 PM",
        type: "Dinner",
        calories: 740,
        protein: 54,
        carbs: 68,
        fat: 22,
        fiber: 10,
        status: "pending",
        vitamins: [
          { name: "Selenium", amount: "44 mcg", dailyPercent: 80, benefit: "Thyroid hormone T4 to T3 conversion" },
          { name: "Potassium", amount: "910 mg", dailyPercent: 27, benefit: "Blunts nocturnal cortisol peaks" }
        ]
      }
    ]
  },
  {
    dayName: "Wednesday",
    date: "Sep 16",
    targetCalories: 2700,
    targetProtein: 200,
    targetCarbs: 290,
    targetFat: 76,
    changeHistory: [],
    meals: [
      {
        id: "m-wed-1",
        name: "Oatmeal with Almond Butter & Egg Whites",
        time: "07:30 AM",
        type: "Breakfast",
        calories: 590,
        protein: 42,
        carbs: 62,
        fat: 18,
        fiber: 9,
        status: "pending",
        vitamins: [
          { name: "Beta-Glucan", amount: "3.2 g", dailyPercent: 100, benefit: "Lowers LDL cholesterol & stabilizes insulin" },
          { name: "Iron", amount: "3.9 mg", dailyPercent: 30, benefit: "Heme support" }
        ]
      },
      {
        id: "m-wed-2",
        name: "Pacific Cod Loin with Jasmine Rice & Green Beans",
        time: "01:00 PM",
        type: "Lunch",
        calories: 640,
        protein: 54,
        carbs: 68,
        fat: 14,
        fiber: 6,
        status: "pending",
        vitamins: [
          { name: "Vitamin B12", amount: "3.4 mcg", dailyPercent: 142, benefit: "Nerve myelin sheath preservation" },
          { name: "Iodine", amount: "110 mcg", dailyPercent: 73, benefit: "Endocrine metabolic regulation" }
        ]
      },
      {
        id: "m-wed-3",
        name: "Grass-Fed Ribeye with Roasted Cauliflower & Truffle Mash",
        time: "08:00 PM",
        type: "Dinner",
        calories: 820,
        protein: 58,
        carbs: 55,
        fat: 32,
        fiber: 7,
        status: "pending",
        vitamins: [
          { name: "Creatine Monohydrate", amount: "2.1 g", dailyPercent: 100, benefit: "Cellular phosphocreatine resynthesis" },
          { name: "Zinc", amount: "7.1 mg", dailyPercent: 65, benefit: "Anabolic receptor responsiveness" }
        ]
      }
    ]
  },
  {
    dayName: "Thursday",
    date: "Sep 17",
    targetCalories: 2500,
    targetProtein: 190,
    targetCarbs: 240,
    targetFat: 80,
    changeHistory: [],
    meals: [
      {
        id: "m-thu-1",
        name: "Avocado & Smoked Salmon Seeded Toast",
        time: "07:30 AM",
        type: "Breakfast",
        calories: 550,
        protein: 36,
        carbs: 40,
        fat: 24,
        fiber: 8,
        status: "pending",
        vitamins: [
          { name: "Vitamin E", amount: "4.2 mg", dailyPercent: 28, benefit: "Lipid membrane antioxidant protection" },
          { name: "Omega-3", amount: "1800 mg", dailyPercent: 120, benefit: "Endothelial nitric oxide enhancement" }
        ]
      },
      {
        id: "m-thu-2",
        name: "Tenderloin Strips with Steamed Broccoli & Sweet Potato",
        time: "01:00 PM",
        type: "Lunch",
        calories: 700,
        protein: 55,
        carbs: 65,
        fat: 22,
        fiber: 9,
        status: "pending",
        vitamins: [
          { name: "Vitamin C", amount: "80 mg", dailyPercent: 88, benefit: "Immune defense" },
          { name: "Iron", amount: "4.1 mg", dailyPercent: 32, benefit: "Tissue oxygenation" }
        ]
      },
      {
        id: "m-thu-3",
        name: "Free-Range Chicken Breast Salad with Walnuts & Olive Oil",
        time: "07:30 PM",
        type: "Dinner",
        calories: 680,
        protein: 56,
        carbs: 35,
        fat: 30,
        fiber: 9,
        status: "pending",
        vitamins: [
          { name: "Monounsaturated Fats", amount: "22 g", dailyPercent: 75, benefit: "Cardiovascular lipid profile optimization" }
        ]
      }
    ]
  },
  {
    dayName: "Friday",
    date: "Sep 18",
    targetCalories: 2650,
    targetProtein: 195,
    targetCarbs: 280,
    targetFat: 75,
    changeHistory: [],
    meals: [
      {
        id: "m-fri-1",
        name: "Eggs Florentine with Spinach & Sourdough",
        time: "07:30 AM",
        type: "Breakfast",
        calories: 580,
        protein: 40,
        carbs: 46,
        fat: 23,
        fiber: 6,
        status: "pending",
        vitamins: [
          { name: "Lutein & Zeaxanthin", amount: "12 mg", dailyPercent: 100, benefit: "Optical macular retinal protection" },
          { name: "Folate (B9)", amount: "210 mcg", dailyPercent: 52, benefit: "Cellular DNA methylation" }
        ]
      },
      {
        id: "m-fri-2",
        name: "Wild Alaskan Halibut with Wild Rice & Asparagus",
        time: "01:00 PM",
        type: "Lunch",
        calories: 670,
        protein: 52,
        carbs: 62,
        fat: 18,
        fiber: 7,
        status: "pending",
        vitamins: [
          { name: "Magnesium", amount: "120 mg", dailyPercent: 29, benefit: "ATP synthase catalyst" }
        ]
      },
      {
        id: "m-fri-3",
        name: "Bison Sirloin Burger (Bun-less) with Baked Wedges",
        time: "07:45 PM",
        type: "Dinner",
        calories: 790,
        protein: 58,
        carbs: 68,
        fat: 26,
        fiber: 8,
        status: "pending",
        vitamins: [
          { name: "CoQ10", amount: "4.5 mg", dailyPercent: 90, benefit: "Mitochondrial electron transport efficiency" }
        ]
      }
    ]
  },
  {
    dayName: "Saturday",
    date: "Sep 19",
    targetCalories: 2850,
    targetProtein: 190,
    targetCarbs: 340,
    targetFat: 72,
    changeHistory: [],
    meals: [
      {
        id: "m-sat-1",
        name: "Cottage Cheese Protein Pancakes with Maple & Fresh Berries",
        time: "08:30 AM",
        type: "Breakfast",
        calories: 650,
        protein: 48,
        carbs: 82,
        fat: 14,
        fiber: 8,
        status: "pending",
        vitamins: [
          { name: "Calcium", amount: "380 mg", dailyPercent: 38, benefit: "Bone & joint resilience" },
          { name: "Vitamin C", amount: "45 mg", dailyPercent: 50, benefit: "Free-radical scavenging" }
        ]
      },
      {
        id: "m-sat-2",
        name: "Mediterranean Grilled Lamb Chop Skewers & Couscous",
        time: "01:30 PM",
        type: "Lunch",
        calories: 780,
        protein: 54,
        carbs: 70,
        fat: 28,
        fiber: 7,
        status: "pending",
        vitamins: [
          { name: "Carnitine", amount: "80 mg", dailyPercent: 100, benefit: "Long-chain fatty acid mitochondrial oxidation" }
        ]
      },
      {
        id: "m-sat-3",
        name: "Wood-Fired Salmon with Truffle Potato Gnocchi",
        time: "08:00 PM",
        type: "Dinner",
        calories: 840,
        protein: 52,
        carbs: 88,
        fat: 26,
        fiber: 6,
        status: "pending",
        vitamins: [
          { name: "Omega-3", amount: "2200 mg", dailyPercent: 135, benefit: "Neuronal membrane repair" }
        ]
      }
    ]
  },
  {
    dayName: "Sunday",
    date: "Sep 20",
    targetCalories: 2400,
    targetProtein: 185,
    targetCarbs: 220,
    targetFat: 78,
    changeHistory: [],
    meals: [
      {
        id: "m-sun-1",
        name: "Poached Eggs, Roasted Tomatoes, Avocado & Goat Cheese",
        time: "09:00 AM",
        type: "Breakfast",
        calories: 540,
        protein: 34,
        carbs: 32,
        fat: 28,
        fiber: 7,
        status: "pending",
        vitamins: [
          { name: "Lycopene", amount: "8.5 mg", dailyPercent: 100, benefit: "Prostate & cardiovascular protection" }
        ]
      },
      {
        id: "m-sun-2",
        name: "Slow-Cooked Bone Broth Stew with Lean Beef & Root Veggies",
        time: "02:00 PM",
        type: "Lunch",
        calories: 660,
        protein: 54,
        carbs: 52,
        fat: 22,
        fiber: 8,
        status: "pending",
        vitamins: [
          { name: "Bioactive Collagen Peptides", amount: "14 g", dailyPercent: 100, benefit: "Articular cartilage & ligament matrix regeneration" }
        ]
      },
      {
        id: "m-sun-3",
        name: "Roasted Herb Chicken Breast with Zucchini & Cauliflower Mash",
        time: "07:30 PM",
        type: "Dinner",
        calories: 620,
        protein: 56,
        carbs: 30,
        fat: 26,
        fiber: 8,
        status: "pending",
        vitamins: [
          { name: "Potassium", amount: "840 mg", dailyPercent: 25, benefit: "Intracellular fluid retention regulation" }
        ]
      }
    ]
  }
];

export const INITIAL_BIOMETRICS: BiometricsData = {
  heartRate: 64,
  restingHeartRate: 58,
  temperature: 98.4,
  bpSystolic: 118,
  bpDiastolic: 76,
  spO2: 99,
  hrv: 72,
  steps: 8420,
  caloriesBurned: 1940,
  activeIntensity: "Zone 2",
  syncedAt: "Just now (Smartwatch Ultra 2 Live)"
};

export const ILLNESS_SIMULATED_BIOMETRICS: BiometricsData = {
  heartRate: 98,
  restingHeartRate: 86,
  temperature: 101.4,
  bpSystolic: 132,
  bpDiastolic: 88,
  spO2: 96,
  hrv: 28,
  steps: 2150,
  caloriesBurned: 1380,
  activeIntensity: "Rest",
  syncedAt: "Anomaly detected via Optical Sensor"
};

export const COMMON_EXERCISES = [
  {
    name: "Barbell Back Squat",
    targetJoints: "Hip & Knee extension, Lumbar spine",
    commonFaults: [
      "Valgus Knee Collapse (Knees caving inward under load)",
      "Lumbar Flexion (Butt wink / rounded lower back in deep hole)",
      "Forward Heel Rise (Shifting weight excessively into toes)"
    ],
    defaultFault: "Valgus Knee Collapse (Knees caving inward under load)"
  },
  {
    name: "Conventional Deadlift",
    targetJoints: "Posterior chain, Thoracolumbar fascia",
    commonFaults: [
      "Lumbar Spine Hyperextension / Rounding on initial pull",
      "Bar drifting away from shins (lats unlatched)",
      "Early knee extension (hips shooting up first)"
    ],
    defaultFault: "Lumbar Spine Hyperextension / Rounding on initial pull"
  },
  {
    name: "Barbell Flat Bench Press",
    targetJoints: "Glenohumeral joint, Pectoralis, Triceps",
    commonFaults: [
      "Elbows flared at 90° (Anterior capsule impingement)",
      "Scapular protraction & losing upper-back arch",
      "Bouncing barbell aggressively off sternum"
    ],
    defaultFault: "Elbows flared at 90° (Anterior capsule impingement)"
  },
  {
    name: "Standing Overhead Military Press",
    targetJoints: "Rotator cuff, Deltoids, Core stabilization",
    commonFaults: [
      "Excessive lumbar arching / pelvic anterior tilt",
      "Head forward neck craning before bar clears nose",
      "Grip too wide causing wrist hyper-extension"
    ],
    defaultFault: "Excessive lumbar arching / pelvic anterior tilt"
  },
  {
    name: "Barbell Bent-Over Row",
    targetJoints: "Latissimus dorsi, Rhomboids, Erector spinae",
    commonFaults: [
      "Jerking torso upward using momentum",
      "Cervical hyperextension (craning neck upward)",
      "Rounding thoracic spine"
    ],
    defaultFault: "Rounding thoracic spine"
  }
];

export const PRESET_FORM_ANALYSIS: Record<string, FormFaultAnalysis> = {
  "Valgus Knee Collapse (Knees caving inward under load)": {
    exercise: "Barbell Back Squat",
    mistake: "Valgus Knee Collapse (Knees caving inward under load)",
    severity: "Severe",
    biomechanicalHarms: [
      "Multiplies medial shear forces across the anterior cruciate ligament (ACL) up to 340%, severely elevating acute tear vulnerability.",
      "Creates focal patellofemoral compressive stress against the lateral femoral condyle, eroding articular cartilage.",
      "De-activates primary gluteus medius abductors while placing chronic strain on adductor magnus and MCL."
    ],
    voiceNoteScript: "Attention athlete from fecheat AI. Your back squat shows pronounced knee valgus collapse in the concentric drive. This creates acute torsional shear on your ACL and accelerates cartilage attrition. Before your next rep, screw your feet into the floor, actively spread the floor, and drive your patellas over your outer toes.",
    correctiveCues: [
      "Screw your heels into the ground creating external rotation torque in the hip capsule.",
      "Imagine spreading a sheet of paper between your feet.",
      "Keep kneecaps tracking directly over the second and third metatarsals."
    ],
    youtubeTutorials: [
      {
        title: "How to Stop Knees Caving In (Squat Valgus Fix)",
        channel: "Squat University (Dr. Aaron Horschig)",
        searchQuery: "squat university knees caving in valgus fix",
        focusCue: "Rooting drill and banded external rotation priming at 04:12"
      },
      {
        title: "The Most Dangerous Squat Mistake You're Making",
        channel: "Jeff Nippard",
        searchQuery: "jeff nippard squat mistakes knee cave",
        focusCue: "Anatomy of knee stability & stance width calibration at 02:45"
      },
      {
        title: "Stop Ruining Your Knees on Squats",
        channel: "Athlean-X",
        searchQuery: "athlean x knee cave fix squat",
        focusCue: "Glute medius activation warmup drill"
      }
    ]
  },
  "Lumbar Spine Hyperextension / Rounding on initial pull": {
    exercise: "Conventional Deadlift",
    mistake: "Lumbar Spine Hyperextension / Rounding on initial pull",
    severity: "Critical",
    biomechanicalHarms: [
      "Transfers thousands of Newtons of shear load straight off the thoracolumbar fascia onto the L4-L5 and L5-S1 intervertebral discs.",
      "Massive herniation and disc extrusion hazard under heavy loaded deadlift pulls.",
      "Inactivates latissimus dorsi bracing, allowing the barbell to drift forward and multiplying lumbar moment arms."
    ],
    voiceNoteScript: "fecheat safety protocol engaged. Your lumbar spine is flexing in the floor break of your deadlift. You are levering spinal discs under thousands of pounds of pressure. Lower the bar, pack your lats into your back pockets, wedge your hips into the barbell, and push the floor away.",
    correctiveCues: [
      "Protect your armpits: pull lats down like bending the bar in half around your shins.",
      "Pull all slack out of the barbell until you hear the click before breaking the floor.",
      "Brace with 360-degree intra-abdominal pressure into your belt."
    ],
    youtubeTutorials: [
      {
        title: "How to Deadlift Without Hurting Your Lower Back",
        channel: "Squat University",
        searchQuery: "deadlift lower back pain fix squat university",
        focusCue: "Intervertebral shear vs compression analysis at 03:20"
      },
      {
        title: "Deadlift Form Checklist (Step-by-Step)",
        channel: "Jeremy Ethier",
        searchQuery: "jeremy ethier deadlift form checklist fix rounded back",
        focusCue: "Barbell-to-shin proximity & hip hinge setup at 01:50"
      }
    ]
  }
};

export const DEFAULT_DAY_SCHEDULE = DEFAULT_SCHEDULE;
export const DEFAULT_BIOMETRICS = INITIAL_BIOMETRICS;

export const DEFAULT_ILLNESS_ASSESSMENT: import("../types").IllnessAssessment = {
  active: true,
  triageStatus: "Acute Febrile Response & Viral Fatigue",
  biometricAnomalySummary: "Smartwatch optical sensors detected core temperature elevation to 101.4°F and an elevated pulse of 102 bpm.",
  symptomsReported: ["Fever, shivering, muscle soreness, fatigue"],
  userConsent: true,
  generalMedicines: [
    {
      name: "Acetaminophen / Paracetamol (500mg)",
      purpose: "Antipyretic fever reducer and analgesic for diffuse muscular aching.",
      timing: "Every 6-8 hours with a full glass of water (max 3g/day)."
    },
    {
      name: "Oral Rehydration Salts (WHO formula ORS)",
      purpose: "Restores electrolyte sodium-potassium balance and combats dehydration.",
      timing: "Sip 1.5 - 2 Liters throughout the day."
    },
    {
      name: "Zinc Glycinate (25mg) & Ascorbic Acid (500mg)",
      purpose: "Enhances mucosal barrier protection and leukocyte phagocytosis.",
      timing: "Take once daily with a light meal."
    }
  ],
  doctorDossier: {
    patientSummary: "Athlete presenting with sudden febrile deviation (101.4°F) and resting tachycardia (102 bpm). Telemetry synced via smartwatch.",
    symptomTimeline: "Acute onset in last 12-24 hours. Primary symptoms: fever, myalgia, fatigue.",
    vitalsLogged: "Temp: 101.4°F | HR: 102 bpm | BP: 132/88 | SpO2: 96%",
    flagsForPhysician: "Check for throat erythema, orthostatic dizziness upon standing, and pulmonary crackles if fever persists >48h."
  },
  automaticIllnessDietAdjustment: {
    adjustedProtocolName: "Febrile Recovery & Gut-Sparing Protocol",
    rationale: "Digesting dense whole meats redirects blood flow from immune cellular defense. Diet shifted automatically to bone broths, jasmine rice, and warm electrolytes.",
    dailySchedule: [
      { time: "08:00 AM", meal: "Ginger, Turmeric & Manuka Honey warm infusion with 2 soft poached eggs" },
      { time: "12:30 PM", meal: "Slow-Simmered Chicken Bone Broth with glutinous white rice & carrots" },
      { time: "04:30 PM", meal: "Fresh Coconut Water with pinch of pink Himalayan salt & sliced papaya" },
      { time: "08:00 PM", meal: "Moong Dal Khichdi or light potato leek puree with probiotic yogurt" }
    ]
  },
  workoutRecommendation: "STRICT REST. Do not train. Strenuous workouts during active viral fever can cause viral myocarditis.",
  detectedAt: "Just now"
};

